# COMPUTER 1: start the astronaut bio-chip simulator as a BLE peripheral.
Set-Location (Join-Path $PSScriptRoot "..")
cargo run --release -p bio-chip-sim -- --mode ble @args
