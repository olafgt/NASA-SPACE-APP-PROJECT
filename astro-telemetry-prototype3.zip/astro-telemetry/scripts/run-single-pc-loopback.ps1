# SINGLE PC: simulator (TCP loopback) in its own window + Ground Control.
Set-Location (Join-Path $PSScriptRoot "..")
cargo build --release -p bio-chip-sim -p ground-control
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PWD'; .\target\release\bio-chip-sim.exe --mode tcp"
Start-Sleep -Seconds 1
.\target\release\ground-control.exe --source tcp
