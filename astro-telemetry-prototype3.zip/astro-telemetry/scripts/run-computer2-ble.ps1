# COMPUTER 2: start Ground Control, receiving telemetry over Bluetooth LE.
Set-Location (Join-Path $PSScriptRoot "..")
cargo run --release -p ground-control -- --source ble @args
