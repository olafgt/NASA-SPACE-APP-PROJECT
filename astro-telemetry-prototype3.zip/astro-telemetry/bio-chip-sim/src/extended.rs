//! Extended physiology: the slow and environment-driven signals behind the four
//! spaceflight hazard groups on the project sheet.
//!
//! | hazard | simulated signals |
//! |---|---|
//! | Space radiation | lymphocyte count, HRV, arterial stiffness (PWV), reaction time/errors, cumulative dose |
//! | Isolation & behavioral | sleep, mood, reaction time drift, workload, social contact + Earth comms, self-check / report delay |
//! | Altered gravity | bone-turnover marker (NTx), lean mass, leg strength, fluid index, orthostatic HR rise, mechanical loading, nutrition (Ca, kcal, vitamin D, sodium) |
//! | Hostile closed environment | cabin CO2/O2/PM2.5/humidity, respiratory rate, cortisol, CRP, microbial load |
//!
//! ## Mission clock
//! One simulator tick advances the mission clock by `time_scale * interval` seconds
//! (default 3600x: 1 s = 1 mission hour, 1 mission day = 24 s). Slow processes
//! (bone, muscle, fluids, dose) integrate over *mission* time; event responses
//! (infection, CO2 build-up ...) play out over *ticks* so they are visible in a demo.
//!
//! ## Honesty note
//! All coefficients are illustrative, chosen to produce plausible-looking trends
//! for software testing. This is not a clinical model. Several signals (bone
//! markers, cytokines, cognitive tests) would never come from an implant in
//! reality; here they stand for periodic measurements.

use crate::physiology::EventKind;
use rand::{rngs::StdRng, Rng, SeedableRng};
use std::f64::consts::TAU;
use telemetry_protocol::{ExtendedVitals, RawTelemetry};

// Nominal baselines (also used by analysis.py as population norms).
const LYMPH0: f64 = 2200.0;
const HRV0: f64 = 45.0;
const PWV0: f64 = 7.0;
const RT0: f64 = 250.0;
const LEAN0: f64 = 58.0;
const NTX0: f64 = 30.0;
const EXERCISE_TARGET_MIN: f64 = 120.0;

pub struct ExtendedModel {
    rng: StdRng,
    time_scale: f64,
    dt_h: f64,
    start_day: f64,
    mission_h: f64,
    /// Cumulative effective dose, mSv.
    dose_msv: f64,
    last_day_int: i64,

    // event-driven (tick time-constants)
    lymph_dev: f64,
    cortisol: f64,
    crp: f64,
    microbial: f64,
    co2: f64,
    o2: f64,

    // daily-measured
    sleep_h: f64,
    sleep_eff: f64,
    mood: f64,
    exercise_min: f64,
    /// Smoothed exercise-countermeasure adherence (1.0 = full programme).
    adherence: f64,

    // slow, continuous (mission-day time-constants)
    ntx: f64,
    lean: f64,
    fluid: f64,
    ortho: f64,
    vitd: f64,

    // daily-measured: nutrition, loading, workload, confinement, reporting
    calcium: f64,
    energy: f64,
    sodium: f64,
    /// Smoothed nutrition adequacy (1.0 = fully adequate).
    nutr: f64,
    mech_load: f64,
    workload: f64,
    work_hours: f64,
    social: f64,
    earth_comm: f64,
    selfcheck: f64,
    peer_check: f64,
    report_delay: f64,
}

fn lag(cur: f64, target: f64, tau_ticks: f64) -> f64 {
    cur + (target - cur) / tau_ticks
}

impl ExtendedModel {
    /// `interval_s` = real seconds per tick.
    pub fn new(seed: Option<u64>, time_scale: f64, interval_s: f64, start_day: f64) -> Self {
        let rng = match seed {
            Some(s) => StdRng::seed_from_u64(s.wrapping_add(0x5eed)),
            None => StdRng::from_entropy(),
        };
        let time_scale = time_scale.max(0.0);
        Self {
            rng,
            time_scale,
            dt_h: time_scale * interval_s / 3600.0,
            start_day,
            mission_h: 0.0,
            dose_msv: 0.0,
            last_day_int: i64::MIN,
            lymph_dev: 0.0,
            cortisol: 12.0,
            crp: 1.0,
            microbial: 120.0,
            co2: 2.2,
            o2: 20.9,
            sleep_h: 7.2,
            sleep_eff: 90.0,
            mood: 78.0,
            exercise_min: EXERCISE_TARGET_MIN,
            adherence: 1.0,
            ntx: NTX0,
            lean: LEAN0,
            fluid: 1.0 + 0.04 + 0.10,
            ortho: 12.0,
            vitd: 34.0,
            calcium: 1000.0,
            energy: 2700.0,
            sodium: 3200.0,
            nutr: 1.0,
            mech_load: 100.0,
            workload: 55.0,
            work_hours: 8.5,
            social: 150.0,
            earth_comm: 45.0,
            selfcheck: 95.0,
            peer_check: 92.0,
            report_delay: 1.5,
        }
    }

    pub fn mission_day(&self) -> f64 {
        self.start_day + self.mission_h / 24.0
    }
    pub fn dose_msv(&self) -> f64 {
        self.dose_msv
    }

    fn gauss(&mut self) -> f64 {
        let u1: f64 = self.rng.gen::<f64>().max(1e-12);
        let u2: f64 = self.rng.gen::<f64>();
        (-2.0 * u1.ln()).sqrt() * (TAU * u2).cos()
    }

    /// Advance one tick. `core` is the just-produced core sample, `ev` the
    /// currently active scenario event.
    pub fn step(&mut self, core: &RawTelemetry, ev: Option<EventKind>) -> ExtendedVitals {
        use EventKind::*;
        self.mission_h += self.dt_h;
        let day = self.mission_day();
        let dt_days = self.dt_h / 24.0;
        self.dose_msv += core.radiation_usv_h * self.dt_h / 1000.0;
        let dose = self.dose_msv;

        // ---- daily rollover: workload, nutrition, social, sleep, mood, exercise, reporting ----
        let day_int = day.floor() as i64;
        if day_int != self.last_day_int {
            self.last_day_int = day_int;
            let iso_days = (day - self.start_day).max(0.0);

            // workload
            let surge = matches!(ev, Some(WorkloadSurge));
            self.workload =
                (55.0 + 0.05 * iso_days + 6.0 * self.gauss() + if surge { 33.0 } else { 0.0 })
                    .clamp(0.0, 100.0);
            self.work_hours =
                (8.5 + 0.5 * self.gauss() + if surge { 4.5 } else { 0.0 }).clamp(4.0, 16.0);

            // nutrition (feeds bone turnover and vitamin D)
            let poor = matches!(ev, Some(PoorNutrition));
            self.calcium =
                (1000.0 + 80.0 * self.gauss() - if poor { 550.0 } else { 0.0 }).max(100.0);
            self.energy =
                (2700.0 + 150.0 * self.gauss() - if poor { 1200.0 } else { 0.0 }).max(500.0);
            self.sodium = (3200.0 + 250.0 * self.gauss()).max(500.0);
            let adequacy =
                (0.5 * self.calcium / 1000.0 + 0.5 * self.energy / 2700.0).clamp(0.0, 1.1);
            self.nutr += 0.5 * (adequacy - self.nutr);

            // confinement: social contact and Earth communication
            let outage = matches!(ev, Some(CommsOutage));
            self.social = (150.0 - 0.15 * iso_days + 25.0 * self.gauss()
                - if outage { 115.0 } else { 0.0 })
            .max(0.0);
            self.earth_comm = if outage {
                (2.0 + 2.0 * self.gauss()).max(0.0)
            } else {
                (45.0 + 10.0 * self.gauss()).max(0.0)
            };

            // sleep (long work days steal sleep)
            let loss = matches!(ev, Some(SleepLoss));
            self.sleep_h = (7.3 - 0.004 * day + 0.3 * self.gauss()
                - 0.3 * (self.work_hours - 10.0).max(0.0)
                - if loss { 2.8 } else { 0.0 })
            .clamp(2.0, 10.0);
            self.sleep_eff =
                (90.0 + 2.0 * self.gauss() - if loss { 11.0 } else { 0.0 }).clamp(50.0, 98.0);

            // mood (sleep, isolation from crew and Earth, and workload all weigh on it)
            let mood_target = 78.0
                - 0.10 * iso_days
                - 4.0 * (7.0 - self.sleep_h).max(0.0)
                - 0.08 * (120.0 - self.social).max(0.0)
                - 0.12 * (30.0 - self.earth_comm).max(0.0)
                - 0.05 * (self.workload - 70.0).max(0.0)
                - if matches!(ev, Some(MoodDip)) {
                    26.0
                } else {
                    0.0
                };
            self.mood = (self.mood + 0.4 * (mood_target - self.mood) + 1.5 * self.gauss())
                .clamp(5.0, 100.0);

            // exercise / mechanical loading
            self.exercise_min = if matches!(ev, Some(SkipExercise)) {
                (8.0 + 3.0 * self.gauss()).max(0.0)
            } else {
                (EXERCISE_TARGET_MIN + 12.0 * self.gauss()).max(0.0)
            };
            self.adherence += 0.5 * (self.exercise_min / EXERCISE_TARGET_MIN - self.adherence);
            self.mech_load = (100.0 * (self.exercise_min / EXERCISE_TARGET_MIN).min(1.3)
                + 4.0 * self.gauss())
            .clamp(0.0, 130.0);

            // self-monitoring and reporting (workload and low mood erode it)
            let silent = matches!(ev, Some(ReportSilence));
            self.selfcheck = (95.0 + 3.0 * self.gauss()
                - 0.4 * (self.workload - 60.0).max(0.0)
                - 0.3 * (70.0 - self.mood).max(0.0)
                - if silent { 58.0 } else { 0.0 })
            .clamp(0.0, 100.0);
            self.peer_check = (92.0 + 4.0 * self.gauss()
                - 0.2 * (self.workload - 70.0).max(0.0)
                - if silent { 22.0 } else { 0.0 })
            .clamp(0.0, 100.0);
            self.report_delay = (1.5
                + 0.4 * self.gauss().abs()
                + 0.12 * (95.0 - self.selfcheck).max(0.0)
                + if silent { 10.0 } else { 0.0 })
            .max(0.2);
        }
        let e = self.adherence.clamp(0.0, 1.0);

        // ---- event-driven signals ----------------------------------------
        let infected = matches!(ev, Some(Infection));
        let fever = matches!(ev, Some(Fever));
        let spe_acute = ((core.radiation_usv_h - 30.0) / 350.0).clamp(0.0, 1.0);

        let lymph_dev_target = if infected { -520.0 } else { 0.0 }
            - 220.0 * spe_acute
            - 30.0 * (self.cortisol - 12.0).max(0.0);
        self.lymph_dev = lag(self.lymph_dev, lymph_dev_target, 8.0);

        let mut cort_t = 12.0 + 0.03 * (day - self.start_day).max(0.0);
        cort_t += match ev {
            Some(Tachycardia) => 5.0,
            Some(Hypoxia) => 4.0,
            Some(SolarParticleEvent) => 3.0,
            Some(Infection) => 6.0,
            Some(SleepLoss) => 3.0,
            Some(Fever) => 4.0,
            Some(MoodDip) => 2.5,
            Some(WorkloadSurge) => 3.0,
            Some(CommsOutage) => 2.0,
            _ => 0.0,
        };
        self.cortisol = lag(self.cortisol, cort_t, 6.0);

        let crp_t = 1.0
            + if infected { 18.0 } else { 0.0 }
            + if fever { 8.0 } else { 0.0 }
            + 4.0 * spe_acute;
        self.crp = lag(self.crp, crp_t, 8.0);

        let micro_t =
            120.0 + 0.5 * (day - self.start_day).max(0.0) + if infected { 1500.0 } else { 0.0 };
        self.microbial = lag(self.microbial, micro_t, 10.0);

        let co2_t = if matches!(ev, Some(Co2Buildup)) {
            7.0
        } else {
            2.2
        };
        self.co2 = lag(self.co2, co2_t, 6.0);
        let o2_t = if matches!(ev, Some(Hypoxia)) {
            17.4
        } else {
            20.9
        };
        self.o2 = lag(self.o2, o2_t, 5.0);

        // ---- slow, mission-time signals ----------------------------------
        // Bone-turnover marker rises with unloading; exercise offsets 60 % of it.
        // Poor nutrition (low calcium / energy) adds up to 50 % to the unloading response.
        let ntx_t = NTX0
            + 14.0
                * (1.0 - (-(day - 1.0).max(0.0) / 20.0).exp())
                * (1.0 - 0.6 * e)
                * (1.0 + 0.5 * (1.0 - self.nutr).max(0.0));
        // Vitamin D follows nutrition adequacy slowly (~10-day time constant).
        let vitd_t = 34.0 - 40.0 * (1.0 - self.nutr).max(0.0);
        self.vitd += (vitd_t - self.vitd) * (1.0 - (-dt_days / 10.0).exp());
        self.ntx += (ntx_t - self.ntx) * (1.0 - (-dt_days / 5.0).exp());

        // Lean-mass loss per day: 0.25 % unmitigated, ~0.05 % with full exercise.
        let loss_rate = 0.0025 * (1.0 - 0.8 * e) + if infected { 0.001 } else { 0.0 };
        self.lean -= self.lean * loss_rate * dt_days;

        // Headward fluid shift: spike on entry, settles ~4 % above baseline;
        // elevated blood pressure adds retention.
        let fluid_t = 1.04
            + 0.10 * (-(day - 1.0).max(0.0) / 4.0).exp()
            + 0.0012 * (core.bp_systolic_mmhg - 130.0).max(0.0);
        self.fluid += (fluid_t - self.fluid) * (1.0 - (-dt_days / 0.3).exp()).max(0.0);

        // Orthostatic HR rise on the stand test: deconditioning grows, exercise offsets 65 %.
        let ortho_t = 12.0 + 22.0 * (1.0 - (-(day - 1.0).max(0.0) / 25.0).exp()) * (1.0 - 0.65 * e);
        self.ortho += (ortho_t - self.ortho) * (1.0 - (-dt_days / 3.0).exp());

        // ---- derived (measured) values -----------------------------------
        let hr = core.heart_rate_bpm;
        let hrv = (HRV0 - 0.25 * (hr - 72.0) - 0.05 * dose
            + 0.10 * (self.mood - 78.0)
            + 1.2 * self.gauss())
        .clamp(8.0, 100.0);
        let pwv =
            PWV0 + 0.004 * dose + 0.015 * (core.bp_systolic_mmhg - 118.0) + 0.04 * self.gauss();
        let lymph =
            (LYMPH0 - 3.0 * dose + self.lymph_dev + 15.0 * self.gauss()).clamp(200.0, 4000.0);
        let rt = (RT0
            + 0.15 * (day - self.start_day).max(0.0)
            + 55.0 * spe_acute
            + 6.0 * (self.co2 - 3.0).max(0.0)
            + 3.0 * (98.0 - core.spo2_pct).max(0.0)
            + 4.0 * (7.0 - self.sleep_h).max(0.0)
            + 7.0 * self.gauss())
        .clamp(150.0, 900.0);
        let err = (2.0 + 0.05 * (rt - RT0) + 0.4 * self.gauss()).clamp(0.0, 60.0);
        let resp = (14.0
            + 0.05 * (hr - 72.0)
            + 1.4 * (self.co2 - 2.2)
            + 0.7 * (98.0 - core.spo2_pct).max(0.0)
            + 0.4 * self.gauss())
        .clamp(6.0, 45.0);
        let leg = (100.0 * (self.lean / LEAN0).powf(1.5) + 0.8 * self.gauss()).clamp(20.0, 120.0);

        let r = |v: f64, d: i32| {
            let p = 10f64.powi(d);
            (v * p).round() / p
        };
        ExtendedVitals {
            groups_mask: 0b111111,
            hrv_rmssd_ms: r(hrv, 1),
            resp_rate_bpm: r(resp, 1),
            cabin_co2_mmhg: r(self.co2 + 0.04 * self.gauss(), 2),
            cabin_o2_pct: r(self.o2 + 0.03 * self.gauss(), 2),
            pm25_ugm3: r((8.0 + 0.6 * self.gauss()).max(0.0), 1),
            time_scale: self.time_scale.round(),
            lymphocytes_per_ul: lymph.round(),
            arterial_pwv_ms: r(pwv, 2),
            reaction_time_ms: rt.round(),
            reaction_error_pct: r(err, 1),
            microbial_cfu_m3: (self.microbial + 6.0 * self.gauss()).max(0.0).round(),
            cortisol_ugdl: r(self.cortisol + 0.4 * self.gauss(), 1),
            sleep_hours: r(self.sleep_h, 2),
            sleep_efficiency_pct: r(self.sleep_eff, 1),
            mood_score: r(self.mood, 1),
            bone_ntx: r(self.ntx + 0.3 * self.gauss(), 1),
            lean_mass_kg: r(self.lean + 0.05 * self.gauss(), 2),
            fluid_index: r(self.fluid + 0.003 * self.gauss(), 3),
            crp_mgl: r((self.crp + 0.05 * self.gauss()).max(0.0), 2),
            leg_strength_pct: r(leg, 1),
            orthostatic_hr_rise: r((self.ortho + 1.2 * self.gauss()).max(0.0), 1),
            exercise_min: self.exercise_min.round(),
            mission_day: r(day, 1),
            humidity_pct: r(45.0 + 1.2 * self.gauss(), 1),
            vitamin_d_ngml: r(self.vitd + 0.3 * self.gauss(), 1),
            calcium_intake_mg: self.calcium.round(),
            energy_intake_kcal: self.energy.round(),
            mech_load_pct: r(self.mech_load, 1),
            workload_index: r(self.workload, 1),
            work_hours: r(self.work_hours, 1),
            social_contact_min: self.social.round(),
            earth_comm_min: self.earth_comm.round(),
            selfcheck_pct: r(self.selfcheck, 1),
            report_delay_h: r(self.report_delay, 1),
            peer_check_pct: r(self.peer_check, 1),
            sodium_intake_mg: self.sodium.round(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::physiology::Physiology;

    fn run(ticks: usize, ev: Option<EventKind>, seed: u64) -> (ExtendedModel, ExtendedVitals) {
        let mut body = Physiology::new(Some(seed), 0.0);
        let mut m = ExtendedModel::new(Some(seed), 3600.0, 1.0, 1.0);
        let mut last = ExtendedVitals::default();
        for _ in 0..ticks {
            let s = body.step();
            last = m.step(&s, ev);
        }
        (m, last)
    }

    #[test]
    fn nominal_values_are_plausible() {
        let (_, e) = run(200, None, 3);
        assert!((1800.0..2500.0).contains(&e.lymphocytes_per_ul), "{e:?}");
        assert!((25.0..70.0).contains(&e.hrv_rmssd_ms));
        assert!((220.0..300.0).contains(&e.reaction_time_ms));
        assert!(e.cabin_co2_mmhg < 3.0 && e.cabin_o2_pct > 20.0);
        assert!(e.microbial_cfu_m3 < 400.0);
    }

    #[test]
    fn skipping_exercise_accelerates_bone_and_muscle_loss() {
        let (_, good) = run(960, None, 5); // 40 mission days
        let (_, bad) = run(960, Some(EventKind::SkipExercise), 5);
        assert!(
            bad.bone_ntx > good.bone_ntx + 3.0,
            "{} vs {}",
            bad.bone_ntx,
            good.bone_ntx
        );
        assert!(bad.lean_mass_kg < good.lean_mass_kg - 0.5);
        assert!(bad.orthostatic_hr_rise > good.orthostatic_hr_rise + 2.0);
    }

    #[test]
    fn infection_raises_micro_crp_and_cuts_lymphocytes() {
        let (_, e) = run(60, Some(EventKind::Infection), 7);
        assert!(e.microbial_cfu_m3 > 900.0, "{e:?}");
        assert!(e.crp_mgl > 8.0);
        assert!(e.lymphocytes_per_ul < 1900.0);
    }

    #[test]
    fn co2_event_and_hypoxia_move_cabin_gas() {
        let (_, e) = run(40, Some(EventKind::Co2Buildup), 9);
        assert!(e.cabin_co2_mmhg > 5.5, "{e:?}");
        let (_, h) = run(40, Some(EventKind::Hypoxia), 9);
        assert!(h.cabin_o2_pct < 18.5);
    }

    #[test]
    fn dose_accumulates_in_mission_time() {
        // ~18 uSv/h for 240 mission-hours = 4.3 mSv
        let (m, _) = run(240, None, 11);
        assert!((3.5..5.5).contains(&m.dose_msv()), "{}", m.dose_msv());
        assert!((10.5..11.5).contains(&m.mission_day()));
    }

    #[test]
    fn poor_nutrition_cuts_intake_and_vitamin_d_and_raises_bone_marker() {
        let (_, good) = run(24 * 40, None, 21);
        let (_, bad) = run(24 * 40, Some(EventKind::PoorNutrition), 21);
        assert!(
            bad.calcium_intake_mg < 650.0 && bad.energy_intake_kcal < 1800.0,
            "{bad:?}"
        );
        assert!(
            bad.vitamin_d_ngml < good.vitamin_d_ngml - 6.0,
            "{} vs {}",
            bad.vitamin_d_ngml,
            good.vitamin_d_ngml
        );
        assert!(bad.bone_ntx > good.bone_ntx + 1.0);
        assert!(good.vitamin_d_ngml > 30.0 && good.calcium_intake_mg > 800.0);
    }

    #[test]
    fn workload_surge_eats_sleep_and_mood() {
        let (_, calm) = run(24 * 5, None, 23);
        let (_, busy) = run(24 * 5, Some(EventKind::WorkloadSurge), 23);
        assert!(
            busy.workload_index > 80.0 && busy.work_hours > 11.5,
            "{busy:?}"
        );
        assert!(busy.sleep_hours < calm.sleep_hours - 0.4);
        assert!(busy.mood_score < calm.mood_score);
    }

    #[test]
    fn comms_outage_isolates_and_silence_delays_reports() {
        let (_, out) = run(24 * 6, Some(EventKind::CommsOutage), 25);
        assert!(
            out.earth_comm_min < 10.0 && out.social_contact_min < 100.0,
            "{out:?}"
        );
        let (_, quiet) = run(24 * 3, Some(EventKind::ReportSilence), 27);
        assert!(
            quiet.selfcheck_pct < 50.0 && quiet.report_delay_h > 8.0,
            "{quiet:?}"
        );
        let (_, ok) = run(24 * 3, None, 27);
        assert!(ok.selfcheck_pct > 85.0 && ok.report_delay_h < 4.0 && ok.mech_load_pct > 85.0);
    }

    #[test]
    fn fluid_shift_settles() {
        let (_, early) = run(24, None, 13);
        let (_, late) = run(24 * 40, None, 13);
        assert!(early.fluid_index > late.fluid_index + 0.04);
    }
}
