//! Physiological model of an astronaut in low Earth orbit.
//!
//! Each vital follows a mean-reverting random walk (Ornstein–Uhlenbeck process)
//! towards a *target*. Targets come from the resting baseline, a slow
//! "circadian" drift, and — when active — a medical/environmental **event**
//! (EVA stress, cabin O₂ leak, solar particle event, ...). Events ramp in and
//! out smoothly, so Ground Control sees realistic trends rather than steps.

use rand::{rngs::StdRng, Rng, SeedableRng};
use std::f64::consts::TAU;
use std::fmt;
use telemetry_protocol::RawTelemetry;

/// Scenario events that can be injected randomly or from the console.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EventKind {
    /// EVA exertion / acute stress: HR ≈ 145 bpm, BP up.
    Tachycardia,
    /// Vagal episode: HR ≈ 42 bpm.
    Bradycardia,
    /// Cabin O₂ partial-pressure drop: SpO₂ ≈ 86 %, compensatory HR rise.
    Hypoxia,
    /// Solar particle event: cabin dose-rate spikes to ≈ 380 µSv/h.
    SolarParticleEvent,
    /// Infection / heat stress: core temp ≈ 38.9 °C, HR up.
    Fever,
    /// Hypertensive crisis: BP ≈ 182/118.
    Hypertension,
    /// Single-sample sensor artefact (motion glitch) – tests anomaly filtering.
    SensorGlitch,
    /// Cabin ventilation fault: CO2 partial pressure climbs.
    Co2Buildup,
    /// Cabin-acquired infection: microbial load, CRP, mild fever, lymphocytes fall.
    Infection,
    /// Several nights of poor sleep (isolation / workload).
    SleepLoss,
    /// Exercise countermeasures skipped (treadmill/ARED down): bone & muscle loss accelerate.
    SkipExercise,
    /// Low-mood episode (confinement stress).
    MoodDip,
    /// Food fatigue / supply problem: calcium, energy and vitamin D intake fall.
    PoorNutrition,
    /// Crew workload surge: long work days, high task load.
    WorkloadSurge,
    /// Communication outage: little social contact, no Earth link.
    CommsOutage,
    /// Reluctance to report: self-checks skipped, symptoms reported late.
    ReportSilence,
}

impl EventKind {
    pub const RANDOM_POOL: [EventKind; 16] = [
        EventKind::Tachycardia,
        EventKind::Bradycardia,
        EventKind::Hypoxia,
        EventKind::SolarParticleEvent,
        EventKind::Fever,
        EventKind::Hypertension,
        EventKind::SensorGlitch,
        EventKind::Co2Buildup,
        EventKind::Infection,
        EventKind::SleepLoss,
        EventKind::SkipExercise,
        EventKind::MoodDip,
        EventKind::PoorNutrition,
        EventKind::WorkloadSurge,
        EventKind::CommsOutage,
        EventKind::ReportSilence,
    ];

    /// Event duration in ticks (seconds at the default 1 Hz rate).
    fn duration(self) -> u32 {
        match self {
            EventKind::Tachycardia => 40,
            EventKind::Bradycardia => 30,
            EventKind::Hypoxia => 35,
            EventKind::SolarParticleEvent => 45,
            EventKind::Fever => 70,
            EventKind::Hypertension => 35,
            EventKind::SensorGlitch => 1,
            EventKind::Co2Buildup => 45,
            EventKind::Infection => 90,
            EventKind::SleepLoss => 60,
            EventKind::SkipExercise => 240,
            EventKind::MoodDip => 72,
            EventKind::PoorNutrition => 300,
            EventKind::WorkloadSurge => 72,
            EventKind::CommsOutage => 96,
            EventKind::ReportSilence => 120,
        }
    }
}

impl fmt::Display for EventKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            EventKind::Tachycardia => "TACHYCARDIA (EVA stress)",
            EventKind::Bradycardia => "BRADYCARDIA",
            EventKind::Hypoxia => "HYPOXIA (cabin O2 drop)",
            EventKind::SolarParticleEvent => "SOLAR PARTICLE EVENT",
            EventKind::Fever => "FEVER",
            EventKind::Hypertension => "HYPERTENSIVE CRISIS",
            EventKind::SensorGlitch => "SENSOR GLITCH",
            EventKind::Co2Buildup => "CABIN CO2 BUILD-UP",
            EventKind::Infection => "INFECTION",
            EventKind::SleepLoss => "SLEEP LOSS",
            EventKind::SkipExercise => "EXERCISE COUNTERMEASURE SKIPPED",
            EventKind::MoodDip => "LOW-MOOD EPISODE",
            EventKind::PoorNutrition => "POOR NUTRITION",
            EventKind::WorkloadSurge => "WORKLOAD SURGE",
            EventKind::CommsOutage => "COMMUNICATION OUTAGE",
            EventKind::ReportSilence => "REPORTING SILENCE",
        };
        f.write_str(s)
    }
}

#[derive(Debug, Clone, Copy)]
struct Vitals {
    hr: f64,
    spo2: f64,
    temp: f64,
    sys: f64,
    dia: f64,
    rad: f64,
}

const BASELINE: Vitals = Vitals {
    hr: 72.0,
    spo2: 98.2,
    temp: 36.95, // astronauts run ~0.5-1 °C warmer than on Earth; keep it mild
    sys: 118.0,
    dia: 76.0,
    rad: 18.0, // ISS ≈ 0.4–0.5 mSv/day ≈ 17–21 µSv/h
};

/// Per-vital (time-constant in ticks, noise σ per tick).
const DYNAMICS: [(f64, f64); 6] = [
    (5.0, 1.1),    // hr
    (6.0, 0.18),   // spo2
    (25.0, 0.015), // temp (slow, low noise)
    (6.0, 1.4),    // sys
    (6.0, 1.0),    // dia
    (4.0, 0.9),    // rad
];

struct ActiveEvent {
    kind: EventKind,
    elapsed: u32,
    duration: u32,
}

pub struct Physiology {
    rng: StdRng,
    v: Vitals,
    tick: u64,
    seq: u32,
    event: Option<ActiveEvent>,
    /// Probability per tick of a spontaneous random event (when none active).
    pub random_event_rate: f64,
}

impl Physiology {
    pub fn new(seed: Option<u64>, random_event_rate: f64) -> Self {
        let rng = match seed {
            Some(s) => StdRng::seed_from_u64(s),
            None => StdRng::from_entropy(),
        };
        Self {
            rng,
            v: BASELINE,
            tick: 0,
            seq: 0,
            event: None,
            random_event_rate,
        }
    }

    pub fn trigger(&mut self, kind: EventKind) {
        self.event = Some(ActiveEvent {
            kind,
            elapsed: 0,
            duration: kind.duration(),
        });
    }

    /// Cancel any running event; vitals drift back to baseline.
    pub fn clear_event(&mut self) {
        self.event = None;
    }

    pub fn active_event(&self) -> Option<EventKind> {
        self.event.as_ref().map(|e| e.kind)
    }

    fn gauss(&mut self) -> f64 {
        // Box–Muller transform (avoids an extra rand_distr dependency).
        let u1: f64 = self.rng.gen::<f64>().max(1e-12);
        let u2: f64 = self.rng.gen::<f64>();
        (-2.0 * u1.ln()).sqrt() * (TAU * u2).cos()
    }

    /// Targets for this tick: baseline + circadian drift + event envelope.
    fn targets(&self) -> Vitals {
        let t = self.tick as f64;
        let mut tg = BASELINE;
        // Slow ~12-minute oscillation stands in for circadian/activity drift.
        let phase = (TAU * t / 720.0).sin();
        tg.hr += 3.0 * phase;
        tg.temp += 0.12 * phase;
        tg.sys += 3.0 * phase;

        if let Some(ev) = &self.event {
            // Trapezoid envelope: 6-tick ramp in and out.
            let ramp = 6.0_f64;
            let e = if matches!(ev.kind, EventKind::SensorGlitch) {
                1.0
            } else {
                (ev.elapsed as f64 / ramp)
                    .min((ev.duration - ev.elapsed) as f64 / ramp)
                    .clamp(0.0, 1.0)
            };
            let lerp = |base: f64, peak: f64| base + (peak - base) * e;
            match ev.kind {
                EventKind::Tachycardia => {
                    tg.hr = lerp(tg.hr, 146.0);
                    tg.sys = lerp(tg.sys, 152.0);
                    tg.dia = lerp(tg.dia, 92.0);
                    tg.temp = lerp(tg.temp, 37.4);
                }
                EventKind::Bradycardia => {
                    tg.hr = lerp(tg.hr, 42.0);
                    tg.sys = lerp(tg.sys, 98.0);
                    tg.dia = lerp(tg.dia, 62.0);
                }
                EventKind::Hypoxia => {
                    tg.spo2 = lerp(tg.spo2, 85.5);
                    tg.hr = lerp(tg.hr, 108.0);
                }
                EventKind::SolarParticleEvent => {
                    tg.rad = lerp(tg.rad, 380.0);
                }
                EventKind::Fever => {
                    tg.temp = lerp(tg.temp, 38.9);
                    tg.hr = lerp(tg.hr, 96.0);
                }
                EventKind::Hypertension => {
                    tg.sys = lerp(tg.sys, 184.0);
                    tg.dia = lerp(tg.dia, 119.0);
                    tg.hr = lerp(tg.hr, 88.0);
                }
                EventKind::Infection => {
                    tg.temp = lerp(tg.temp, 38.2);
                    tg.hr = lerp(tg.hr, 90.0);
                }
                // These act only on the extended (slow) model.
                EventKind::SensorGlitch
                | EventKind::Co2Buildup
                | EventKind::SleepLoss
                | EventKind::SkipExercise
                | EventKind::MoodDip
                | EventKind::PoorNutrition
                | EventKind::WorkloadSurge
                | EventKind::CommsOutage
                | EventKind::ReportSilence => {}
            }
        }
        tg
    }

    /// Advance one tick and return the new sample.
    pub fn step(&mut self) -> RawTelemetry {
        // Maybe start a spontaneous event.
        if self.event.is_none()
            && self.random_event_rate > 0.0
            && self.rng.gen_bool(self.random_event_rate.min(1.0))
        {
            let idx = self.rng.gen_range(0..EventKind::RANDOM_POOL.len());
            self.trigger(EventKind::RANDOM_POOL[idx]);
        }

        let tg = self.targets();
        let mut cur = [
            self.v.hr,
            self.v.spo2,
            self.v.temp,
            self.v.sys,
            self.v.dia,
            self.v.rad,
        ];
        let tgt = [tg.hr, tg.spo2, tg.temp, tg.sys, tg.dia, tg.rad];
        for i in 0..6 {
            let (tau, sigma) = DYNAMICS[i];
            // Faster tracking while an event is active so peaks are reached.
            let tau = if self.event.is_some() {
                tau.min(4.0)
            } else {
                tau
            };
            let noise = self.gauss() * sigma;
            cur[i] += (tgt[i] - cur[i]) / tau + noise;
        }

        // Physical plausibility clamps.
        self.v = Vitals {
            hr: cur[0].clamp(25.0, 220.0),
            spo2: cur[1].clamp(60.0, 100.0),
            temp: cur[2].clamp(32.0, 42.5),
            sys: cur[3].clamp(60.0, 240.0),
            dia: cur[4].clamp(30.0, 150.0),
            rad: cur[5].clamp(0.5, 6000.0),
        };
        if self.v.dia > self.v.sys - 15.0 {
            self.v.dia = self.v.sys - 15.0;
        }

        // The emitted sample may include a one-off artefact without
        // corrupting the underlying physiological state.
        let mut out = self.v;
        if let Some(ev) = &self.event {
            if ev.kind == EventKind::SensorGlitch {
                // Big enough to trip the z-score detector, small enough that the
                // persistence filter should NOT raise a clinical alarm.
                out.hr = (out.hr + 40.0).min(220.0);
                out.spo2 = (out.spo2 - 5.0).max(60.0);
            }
        }

        // Advance / expire event.
        if let Some(ev) = &mut self.event {
            ev.elapsed += 1;
            if ev.elapsed >= ev.duration {
                self.event = None;
            }
        }

        self.tick += 1;
        let seq = self.seq;
        self.seq = self.seq.wrapping_add(1);

        RawTelemetry {
            seq,
            heart_rate_bpm: round(out.hr, 1),
            spo2_pct: round(out.spo2, 1),
            core_temp_c: round(out.temp, 2),
            bp_systolic_mmhg: out.sys.round(),
            bp_diastolic_mmhg: out.dia.round(),
            radiation_usv_h: round(out.rad, 1),
            received_at_ms: 0,
            ext: Default::default(),
        }
    }
}

fn round(v: f64, decimals: i32) -> f64 {
    let p = 10f64.powi(decimals);
    (v * p).round() / p
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn baseline_is_nominal() {
        let mut p = Physiology::new(Some(1), 0.0);
        for _ in 0..300 {
            let s = p.step();
            assert!((50.0..100.0).contains(&s.heart_rate_bpm), "{s:?}");
            assert!(s.spo2_pct > 94.0, "{s:?}");
        }
    }

    #[test]
    fn tachycardia_reaches_alarm_range() {
        let mut p = Physiology::new(Some(2), 0.0);
        p.trigger(EventKind::Tachycardia);
        let peak = (0..40).map(|_| p.step().heart_rate_bpm).fold(0.0, f64::max);
        assert!(peak > 130.0, "peak {peak}");
    }
}
