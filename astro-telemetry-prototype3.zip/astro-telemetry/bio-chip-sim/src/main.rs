//! # COMPUTER 1 — Astronaut Bio-Chip Simulator
//!
//! Simulates an implantable biomedical chip that samples vitals once per
//! second and broadcasts them:
//!
//! * `--mode ble`  (default) — BLE GATT peripheral, 18-byte notify frames
//! * `--mode tcp`  — Local Mock/Loopback: JSON lines over TCP (single-PC tests)
//! * `--mode both` — both at once
//!
//! While running, type a command + Enter to inject a scenario:
//! `t` tachycardia · `b` bradycardia · `h` hypoxia · `r` solar particle event ·
//! `f` fever · `p` hypertensive crisis · `g` sensor glitch · `n` back to nominal ·
//! `q` quit · `?` help

mod ble;
mod extended;
mod physiology;
mod tcp;

use anyhow::Result;
use clap::{Parser, ValueEnum};
use physiology::{EventKind, Physiology};
use std::io::BufRead;
use std::sync::mpsc;
use std::thread;
use std::time::{Duration, Instant};
use telemetry_protocol::{encode_ext_frame, encode_frame, DEFAULT_TCP_ADDR};

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
enum Mode {
    /// Bluetooth Low Energy peripheral (Windows 10/11).
    Ble,
    /// Local Mock/Loopback over TCP (JSON lines).
    Tcp,
    /// BLE and TCP simultaneously.
    Both,
}

#[derive(Debug, Parser)]
#[command(
    name = "bio-chip-sim",
    version,
    about = "COMPUTER 1: Astronaut implantable bio-chip telemetry simulator"
)]
struct Args {
    /// Transport to broadcast on.
    #[arg(long, value_enum, default_value_t = Mode::Ble)]
    mode: Mode,

    /// TCP bind address for loopback mode (use 0.0.0.0:7878 for LAN).
    #[arg(long, default_value = DEFAULT_TCP_ADDR)]
    bind: String,

    /// Sampling interval in milliseconds.
    #[arg(long, default_value_t = 1000)]
    interval_ms: u64,

    /// Probability per sample of a spontaneous random medical/environmental event.
    #[arg(long, default_value_t = 0.012)]
    event_rate: f64,

    /// Disable spontaneous events (only console-triggered ones).
    #[arg(long)]
    no_random_events: bool,

    /// RNG seed for reproducible runs.
    #[arg(long)]
    seed: Option<u64>,

    /// Mission seconds per real second (3600 = 1 s is one mission hour, a mission day
    /// passes in 24 s). Use 1 for real time. Slow effects (bone, muscle, dose) need > 1.
    #[arg(long, default_value_t = 3600.0)]
    time_scale: f64,

    /// Mission day the simulation starts on (1 = launch day: strong fluid shift).
    #[arg(long, default_value_t = 1.0)]
    start_day: f64,

    /// Send the periodic extended groups (daily measurements) every N samples.
    #[arg(long, default_value_t = 5)]
    slow_every: u64,

    /// Print one line every N samples (0 = silent).
    #[arg(long, default_value_t = 1)]
    print_every: u64,
}

enum Command {
    Trigger(EventKind),
    Nominal,
    Help,
    Quit,
}

fn print_help() {
    println!(
        "\nCommands (type + Enter):\n  \
         t  tachycardia (EVA stress)     b  bradycardia\n  \
         h  hypoxia (cabin O2 drop)      r  solar particle event (radiation)\n  \
         f  fever                        p  hypertensive crisis\n  \
         g  single-sample sensor glitch  n  cancel event -> nominal\n  \
         c  cabin CO2 build-up           i  infection\n  \
         s  sleep loss (several nights)  x  skip exercise countermeasures\n  \
         m  low-mood episode             d  poor nutrition (diet deficit)\n  \
         w  workload surge               o  communication outage\n  \
         v  reporting silence            ?  help      q  quit\n"
    );
}

fn spawn_console() -> mpsc::Receiver<Command> {
    let (tx, rx) = mpsc::channel();
    thread::Builder::new()
        .name("console".into())
        .spawn(move || {
            let stdin = std::io::stdin();
            for line in stdin.lock().lines() {
                let Ok(line) = line else { break };
                let cmd = match line.trim().to_lowercase().as_str() {
                    "t" => Command::Trigger(EventKind::Tachycardia),
                    "b" => Command::Trigger(EventKind::Bradycardia),
                    "h" => Command::Trigger(EventKind::Hypoxia),
                    "r" => Command::Trigger(EventKind::SolarParticleEvent),
                    "f" => Command::Trigger(EventKind::Fever),
                    "p" => Command::Trigger(EventKind::Hypertension),
                    "g" => Command::Trigger(EventKind::SensorGlitch),
                    "c" => Command::Trigger(EventKind::Co2Buildup),
                    "i" => Command::Trigger(EventKind::Infection),
                    "s" => Command::Trigger(EventKind::SleepLoss),
                    "x" => Command::Trigger(EventKind::SkipExercise),
                    "m" => Command::Trigger(EventKind::MoodDip),
                    "d" => Command::Trigger(EventKind::PoorNutrition),
                    "w" => Command::Trigger(EventKind::WorkloadSurge),
                    "o" => Command::Trigger(EventKind::CommsOutage),
                    "v" => Command::Trigger(EventKind::ReportSilence),
                    "n" => Command::Nominal,
                    "q" | "quit" | "exit" => Command::Quit,
                    "" => continue,
                    _ => Command::Help,
                };
                if tx.send(cmd).is_err() {
                    break;
                }
            }
        })
        .expect("spawn console thread");
    rx
}

fn main() -> Result<()> {
    let args = Args::parse();
    println!("==============================================================");
    println!(
        "  ASTRONAUT BIO-CHIP SIMULATOR  (Computer 1)   mode = {:?}",
        args.mode
    );
    println!("==============================================================");

    // --- Transports ---------------------------------------------------------
    let ble = if matches!(args.mode, Mode::Ble | Mode::Both) {
        match ble::BlePeripheral::start() {
            Ok(p) => Some(p),
            Err(e) if args.mode == Mode::Both => {
                eprintln!("[BLE] disabled: {e:#}\n[BLE] continuing with TCP only.");
                None
            }
            Err(e) => return Err(e),
        }
    } else {
        None
    };

    let tcp = if matches!(args.mode, Mode::Tcp | Mode::Both) {
        Some(tcp::TcpBroadcaster::bind(&args.bind)?)
    } else {
        None
    };

    let rate = if args.no_random_events {
        0.0
    } else {
        args.event_rate
    };
    let mut body = Physiology::new(args.seed, rate);
    let mut ext_model = extended::ExtendedModel::new(
        args.seed,
        args.time_scale,
        args.interval_ms.max(50) as f64 / 1000.0,
        args.start_day,
    );
    let slow_every = args.slow_every.max(1);
    println!(
        "Mission clock: x{} (1 s = {:.2} mission h; 1 mission day = {:.1} s), starting day {}",
        args.time_scale,
        args.time_scale / 3600.0,
        86400.0 / args.time_scale.max(1e-9),
        args.start_day
    );
    let console = spawn_console();
    print_help();

    // --- 1 Hz sampling loop (drift-free scheduling) -------------------------
    let interval = Duration::from_millis(args.interval_ms.max(50));
    let mut next_tick = Instant::now();
    let mut last_event: Option<EventKind> = None;

    loop {
        // Console commands.
        while let Ok(cmd) = console.try_recv() {
            match cmd {
                Command::Trigger(k) => {
                    println!(">>> Injecting event: {k}");
                    body.trigger(k);
                }
                Command::Nominal => {
                    println!(">>> Event cancelled, returning to nominal");
                    body.clear_event();
                }
                Command::Help => print_help(),
                Command::Quit => {
                    println!("Shutting down bio-chip simulator.");
                    return Ok(());
                }
            }
        }

        let mut sample = body.step();
        let ev = body.active_event();
        sample.ext = ext_model.step(&sample, ev);
        let frame = encode_frame(&sample);

        let ble_sent = match &ble {
            Some(p) => {
                let sent = match p.notify(&frame) {
                    Ok(n) => n,
                    Err(e) => {
                        eprintln!("[BLE] notify failed: {e:#}");
                        0
                    }
                };
                // Fast groups every tick, periodic groups every `slow_every` ticks.
                let groups: &[usize] = if sample.seq as u64 % slow_every == 0 {
                    &[0, 1, 2, 3, 4, 5]
                } else {
                    &[0, 1]
                };
                for &g in groups {
                    let f = encode_ext_frame(sample.seq, g, &sample.ext.group_values(g));
                    if let Err(e) = p.notify_ext(&f) {
                        eprintln!("[BLE] ext notify (group {g}) failed: {e:#}");
                    }
                }
                sent
            }
            None => 0,
        };
        if let Some(t) = &tcp {
            t.broadcast(&sample);
        }

        if ev != last_event {
            match ev {
                Some(k) => println!("*** EVENT STARTED: {k}"),
                None => println!("*** Event ended - vitals returning to baseline"),
            }
            last_event = ev;
        }

        if args.print_every > 0 && sample.seq as u64 % args.print_every == 0 {
            let links = format!(
                "{}{}",
                ble.as_ref()
                    .map(|p| format!(" BLE subs:{} sent:{}", p.subscriber_count(), ble_sent))
                    .unwrap_or_default(),
                tcp.as_ref()
                    .map(|t| format!(" TCP clients:{}", t.client_count()))
                    .unwrap_or_default()
            );
            println!(
                "[#{:05}] HR {:5.1} | SpO2 {:4.1}% | T {:5.2} | BP {:3.0}/{:<3.0} | RAD {:6.1} | day {:6.1} dose {:6.2} mSv | LYM {:4.0} HRV {:4.1} RT {:3.0} CO2 {:3.1} |{}",
                sample.seq,
                sample.heart_rate_bpm,
                sample.spo2_pct,
                sample.core_temp_c,
                sample.bp_systolic_mmhg,
                sample.bp_diastolic_mmhg,
                sample.radiation_usv_h,
                sample.ext.mission_day,
                ext_model.dose_msv(),
                sample.ext.lymphocytes_per_ul,
                sample.ext.hrv_rmssd_ms,
                sample.ext.reaction_time_ms,
                sample.ext.cabin_co2_mmhg,
                links
            );
        }

        next_tick += interval;
        let now = Instant::now();
        if next_tick > now {
            thread::sleep(next_tick - now);
        } else {
            next_tick = now; // we fell behind (e.g. BLE stall) – resync
        }
    }
}
