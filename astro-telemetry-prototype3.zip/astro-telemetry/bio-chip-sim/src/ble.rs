//! BLE GATT **peripheral** (server) using the native WinRT API
//! `Windows.Devices.Bluetooth.GenericAttributeProfile.GattServiceProvider`.
//!
//! Exposes one primary service ([`SERVICE_UUID_U128`]) with one characteristic
//! ([`TELEMETRY_CHAR_UUID_U128`], Read + Notify). Every tick the latest
//! 18-byte frame is pushed to all subscribed centrals via `NotifyValueAsync`.
//!
//! Requirements: Windows 10 1803+ and a Bluetooth radio/driver that supports
//! the **peripheral role** (checked at start-up). No pairing is required — the
//! characteristic uses `GattProtectionLevel::Plain`.

pub use imp::BlePeripheral;

#[cfg(windows)]
mod imp {
    use anyhow::{anyhow, bail, Result};
    use std::sync::{
        atomic::{AtomicU32, Ordering},
        Arc, Mutex,
    };
    use telemetry_protocol::{EXT_CHAR_UUID_U128, SERVICE_UUID_U128, TELEMETRY_CHAR_UUID_U128};
    use windows::{
        core::{IInspectable, GUID},
        Devices::Bluetooth::GenericAttributeProfile::{
            GattCharacteristicProperties, GattLocalCharacteristic,
            GattLocalCharacteristicParameters, GattProtectionLevel, GattReadRequestedEventArgs,
            GattServiceProvider, GattServiceProviderAdvertisementStatusChangedEventArgs,
            GattServiceProviderAdvertisingParameters,
        },
        Devices::Bluetooth::{BluetoothAdapter, BluetoothError},
        Foundation::TypedEventHandler,
        Storage::Streams::{DataWriter, IBuffer},
        Win32::System::WinRT::{RoInitialize, RO_INIT_MULTITHREADED},
    };

    /// Attach a human-readable context to a WinRT error.
    fn w<T>(r: windows::core::Result<T>, what: &str) -> Result<T> {
        r.map_err(|e| anyhow!("{what}: {e} (HRESULT 0x{:08X})", e.code().0 as u32))
    }

    fn make_buffer(bytes: &[u8]) -> windows::core::Result<IBuffer> {
        let writer = DataWriter::new()?;
        writer.WriteBytes(bytes)?;
        writer.DetachBuffer()
    }

    pub struct BlePeripheral {
        provider: GattServiceProvider,
        characteristic: GattLocalCharacteristic,
        ext_characteristic: GattLocalCharacteristic,
        latest: Arc<Mutex<Vec<u8>>>,
        subscribers: Arc<AtomicU32>,
    }

    impl BlePeripheral {
        pub fn start() -> Result<Self> {
            // Join the multithreaded apartment (harmless if already initialised).
            unsafe {
                let _ = RoInitialize(RO_INIT_MULTITHREADED);
            }

            // --- 1. Adapter capability check --------------------------------
            let adapter = w(
                BluetoothAdapter::GetDefaultAsync(),
                "BluetoothAdapter::GetDefaultAsync",
            )
            .and_then(|op| {
                w(
                    op.get(),
                    "No Bluetooth adapter found (is Bluetooth switched on?)",
                )
            })?;
            let le = w(adapter.IsLowEnergySupported(), "IsLowEnergySupported")?;
            let periph = w(
                adapter.IsPeripheralRoleSupported(),
                "IsPeripheralRoleSupported",
            )?;
            println!("[BLE] Adapter: LE supported = {le}, peripheral role supported = {periph}");
            if !le || !periph {
                bail!(
                    "This PC's Bluetooth adapter/driver cannot act as a BLE peripheral.\n\
                     Fix: update the Bluetooth driver, use a USB dongle that supports the \
                     peripheral role (e.g. Intel AX200/AX210 class), or run with `--mode tcp \
                     --bind 0.0.0.0:7878` over the LAN instead."
                );
            }

            // --- 2. Create the GATT service ----------------------------------
            let svc_result = w(
                GattServiceProvider::CreateAsync(GUID::from_u128(SERVICE_UUID_U128)),
                "GattServiceProvider::CreateAsync",
            )
            .and_then(|op| w(op.get(), "GattServiceProvider::CreateAsync.get"))?;
            let err = w(svc_result.Error(), "GattServiceProviderResult::Error")?;
            if err != BluetoothError::Success {
                bail!("Could not create GATT service provider: {err:?}");
            }
            let provider = w(svc_result.ServiceProvider(), "ServiceProvider")?;

            // --- 3. Create the telemetry characteristic (Read + Notify) ------
            let params = w(
                GattLocalCharacteristicParameters::new(),
                "CharacteristicParameters",
            )?;
            w(
                params.SetCharacteristicProperties(
                    GattCharacteristicProperties::Read | GattCharacteristicProperties::Notify,
                ),
                "SetCharacteristicProperties",
            )?;
            w(
                params.SetReadProtectionLevel(GattProtectionLevel::Plain),
                "SetReadProtectionLevel",
            )?;

            let service = w(provider.Service(), "GattServiceProvider::Service")?;
            let ch_result = w(
                service
                    .CreateCharacteristicAsync(GUID::from_u128(TELEMETRY_CHAR_UUID_U128), &params),
                "CreateCharacteristicAsync",
            )
            .and_then(|op| w(op.get(), "CreateCharacteristicAsync.get"))?;
            let err = w(ch_result.Error(), "GattLocalCharacteristicResult::Error")?;
            if err != BluetoothError::Success {
                bail!("Could not create GATT characteristic: {err:?}");
            }
            let characteristic = w(ch_result.Characteristic(), "Characteristic")?;

            // --- 3b. Extended-vitals characteristic (Notify only) ------------
            let ext_params = w(
                GattLocalCharacteristicParameters::new(),
                "ExtCharacteristicParameters",
            )?;
            w(
                ext_params.SetCharacteristicProperties(GattCharacteristicProperties::Notify),
                "Ext SetCharacteristicProperties",
            )?;
            let ext_result = w(
                service.CreateCharacteristicAsync(GUID::from_u128(EXT_CHAR_UUID_U128), &ext_params),
                "Ext CreateCharacteristicAsync",
            )
            .and_then(|op| w(op.get(), "Ext CreateCharacteristicAsync.get"))?;
            let err = w(
                ext_result.Error(),
                "Ext GattLocalCharacteristicResult::Error",
            )?;
            if err != BluetoothError::Success {
                bail!("Could not create extended GATT characteristic: {err:?}");
            }
            let ext_characteristic = w(ext_result.Characteristic(), "Ext Characteristic")?;

            let latest = Arc::new(Mutex::new(Vec::<u8>::new()));
            let subscribers = Arc::new(AtomicU32::new(0));

            // --- 4. Event handlers -------------------------------------------
            // 4a. Track how many centrals subscribed to notifications.
            {
                let subs = subscribers.clone();
                let handler = TypedEventHandler::<GattLocalCharacteristic, IInspectable>::new(
                    move |sender, _args| {
                        if let Some(ch) = sender.as_ref() {
                            let n = ch.SubscribedClients()?.Size()?;
                            let prev = subs.swap(n, Ordering::SeqCst);
                            if n > prev {
                                println!("[BLE] Ground Control subscribed ({n} client(s))");
                            } else if n < prev {
                                println!("[BLE] Client unsubscribed ({n} client(s) left)");
                            }
                        }
                        Ok(())
                    },
                );
                w(
                    characteristic.SubscribedClientsChanged(&handler),
                    "SubscribedClientsChanged",
                )?;
            }

            // 4b. Answer plain GATT reads with the most recent frame.
            {
                let latest = latest.clone();
                let handler = TypedEventHandler::<
                    GattLocalCharacteristic,
                    GattReadRequestedEventArgs,
                >::new(move |_sender, args| {
                    if let Some(args) = args.as_ref() {
                        let deferral = args.GetDeferral()?;
                        let request = args.GetRequestAsync()?.get()?;
                        let bytes = latest.lock().map(|b| b.clone()).unwrap_or_default();
                        request.RespondWithValue(&make_buffer(&bytes)?)?;
                        deferral.Complete()?;
                    }
                    Ok(())
                });
                w(characteristic.ReadRequested(&handler), "ReadRequested")?;
            }

            // 4c. Log advertisement state changes (Started / Aborted / ...).
            {
                let handler = TypedEventHandler::<
                    GattServiceProvider,
                    GattServiceProviderAdvertisementStatusChangedEventArgs,
                >::new(|_sender, args| {
                    if let Some(a) = args.as_ref() {
                        println!(
                            "[BLE] Advertisement status: {:?} (error: {:?})",
                            a.Status()?,
                            a.Error()?
                        );
                    }
                    Ok(())
                });
                w(
                    provider.AdvertisementStatusChanged(&handler),
                    "AdvertisementStatusChanged",
                )?;
            }

            // --- 5. Start advertising (connectable + discoverable) ----------
            let adv = w(
                GattServiceProviderAdvertisingParameters::new(),
                "AdvertisingParameters",
            )?;
            w(adv.SetIsConnectable(true), "SetIsConnectable")?;
            w(adv.SetIsDiscoverable(true), "SetIsDiscoverable")?;
            w(
                provider.StartAdvertisingWithParameters(&adv),
                "StartAdvertising",
            )?;

            println!(
                "[BLE] Advertising service {} — waiting for Ground Control to subscribe…",
                telemetry_protocol::SERVICE_UUID
            );

            Ok(Self {
                provider,
                characteristic,
                ext_characteristic,
                latest,
                subscribers,
            })
        }

        pub fn subscriber_count(&self) -> u32 {
            self.subscribers.load(Ordering::SeqCst)
        }

        /// Notify one 19-byte extended-vitals frame to all subscribers.
        pub fn notify_ext(&self, frame: &[u8]) -> Result<u32> {
            if self.subscriber_count() == 0 {
                return Ok(0);
            }
            let buffer = w(make_buffer(frame), "make_buffer")?;
            let results = w(
                self.ext_characteristic.NotifyValueAsync(&buffer),
                "Ext NotifyValueAsync",
            )
            .and_then(|op| w(op.get(), "Ext NotifyValueAsync.get"))?;
            Ok(w(results.Size(), "ext results.Size")?)
        }

        /// Store the frame for reads and notify all subscribers.
        /// Returns the number of clients the notification was sent to.
        pub fn notify(&self, frame: &[u8]) -> Result<u32> {
            if let Ok(mut l) = self.latest.lock() {
                *l = frame.to_vec();
            }
            if self.subscriber_count() == 0 {
                return Ok(0);
            }
            let buffer = w(make_buffer(frame), "make_buffer")?;
            let results = w(
                self.characteristic.NotifyValueAsync(&buffer),
                "NotifyValueAsync",
            )
            .and_then(|op| w(op.get(), "NotifyValueAsync.get"))?;
            Ok(w(results.Size(), "results.Size")?)
        }
    }

    impl Drop for BlePeripheral {
        fn drop(&mut self) {
            let _ = self.provider.StopAdvertising();
            println!("[BLE] Advertising stopped.");
        }
    }
}

#[cfg(not(windows))]
mod imp {
    use anyhow::{bail, Result};

    /// Stub so the simulator still builds (TCP mode) on non-Windows hosts.
    pub struct BlePeripheral;

    impl BlePeripheral {
        pub fn start() -> Result<Self> {
            bail!("BLE peripheral mode uses the WinRT API and requires Windows 10/11. Use `--mode tcp`.")
        }
        pub fn subscriber_count(&self) -> u32 {
            0
        }
        pub fn notify(&self, _frame: &[u8]) -> Result<u32> {
            Ok(0)
        }
        pub fn notify_ext(&self, _frame: &[u8]) -> Result<u32> {
            Ok(0)
        }
    }
}
