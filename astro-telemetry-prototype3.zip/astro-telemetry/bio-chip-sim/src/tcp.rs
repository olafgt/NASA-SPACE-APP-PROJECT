//! Local Mock / Loopback transport.
//!
//! A tiny TCP server that broadcasts every sample as one JSON object per line
//! (`RawTelemetry`). Bind to `127.0.0.1:7878` for single-PC testing, or to
//! `0.0.0.0:7878` to feed a Ground Control PC over the LAN when BLE hardware
//! is unavailable. You can also eyeball the stream with:
//!     PowerShell:  Test-NetConnection 127.0.0.1 -Port 7878   (connectivity)
//!     or any raw TCP client (e.g. `ncat 127.0.0.1 7878`).

use anyhow::{Context, Result};
use std::io::Write;
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;
use telemetry_protocol::RawTelemetry;

pub struct TcpBroadcaster {
    clients: Arc<Mutex<Vec<(String, TcpStream)>>>,
}

impl TcpBroadcaster {
    pub fn bind(addr: &str) -> Result<Self> {
        let listener = TcpListener::bind(addr)
            .with_context(|| format!("could not bind TCP server on {addr}"))?;
        println!("[TCP] Loopback server listening on {addr}");
        let clients: Arc<Mutex<Vec<(String, TcpStream)>>> = Arc::new(Mutex::new(Vec::new()));
        let accept_clients = clients.clone();

        thread::Builder::new()
            .name("tcp-accept".into())
            .spawn(move || {
                for stream in listener.incoming() {
                    match stream {
                        Ok(s) => {
                            let peer = s
                                .peer_addr()
                                .map(|a| a.to_string())
                                .unwrap_or_else(|_| "?".into());
                            let _ = s.set_nodelay(true);
                            // Never let a stalled client freeze the 1 Hz loop.
                            let _ = s.set_write_timeout(Some(Duration::from_secs(2)));
                            println!("[TCP] Ground Control connected from {peer}");
                            if let Ok(mut c) = accept_clients.lock() {
                                c.push((peer, s));
                            }
                        }
                        Err(e) => eprintln!("[TCP] accept error: {e}"),
                    }
                }
            })
            .context("spawn accept thread")?;

        Ok(Self { clients })
    }

    pub fn client_count(&self) -> usize {
        self.clients.lock().map(|c| c.len()).unwrap_or(0)
    }

    /// Send one JSON line to every client, dropping clients whose socket failed.
    pub fn broadcast(&self, sample: &RawTelemetry) {
        let mut line = match serde_json::to_string(sample) {
            Ok(l) => l,
            Err(e) => {
                eprintln!("[TCP] serialise error: {e}");
                return;
            }
        };
        line.push('\n');
        if let Ok(mut clients) = self.clients.lock() {
            clients.retain_mut(|(peer, s)| match s.write_all(line.as_bytes()) {
                Ok(()) => true,
                Err(e) => {
                    println!("[TCP] Client {peer} disconnected ({e})");
                    false
                }
            });
        }
    }
}
