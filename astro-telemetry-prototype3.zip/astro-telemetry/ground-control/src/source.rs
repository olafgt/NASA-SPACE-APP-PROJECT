//! Telemetry sources: BLE central (btleplug) or TCP loopback.
//!
//! Runs on its own OS thread with a Tokio runtime, auto-reconnects forever,
//! stamps each sample with the receive time and forwards it to the Python
//! bridge. Link-state changes go to the UI through [`Notifier`].

use crate::model::{AppEvent, BridgeMsg, LinkState, Notifier};
use anyhow::{bail, Context, Result};
use btleplug::api::{Central, CharPropFlags, Manager as _, Peripheral as _, ScanFilter};
use btleplug::platform::{Adapter, Manager, Peripheral};
use futures::StreamExt;
use std::sync::mpsc::Sender;
use std::time::{Duration, Instant};
use telemetry_protocol::{
    decode_ext_frame, decode_frame, now_ms, ExtendedVitals, RawTelemetry, EXT_CHAR_UUID,
    SERVICE_UUID, TELEMETRY_CHAR_UUID,
};
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::net::TcpStream;

#[derive(Debug, Clone)]
pub enum SourceConfig {
    Ble {
        /// Optional substring of the advertised local name / address to match
        /// (in addition to the service UUID).
        name_filter: Option<String>,
        scan_timeout: Duration,
    },
    Tcp {
        addr: String,
    },
}

/// No data for this long → consider the stream stalled.
const STALL_TIMEOUT: Duration = Duration::from_secs(5);
const RECONNECT_DELAY: Duration = Duration::from_secs(3);

pub fn spawn(cfg: SourceConfig, bridge_tx: Sender<BridgeMsg>, n: Notifier) {
    std::thread::Builder::new()
        .name("telemetry-source".into())
        .spawn(move || {
            let rt = match tokio::runtime::Builder::new_multi_thread()
                .worker_threads(2)
                .enable_all()
                .build()
            {
                Ok(rt) => rt,
                Err(e) => {
                    n.link(LinkState::Error(format!("Tokio runtime failed: {e}")));
                    return;
                }
            };
            rt.block_on(async move {
                match cfg {
                    SourceConfig::Ble {
                        name_filter,
                        scan_timeout,
                    } => ble_forever(name_filter, scan_timeout, bridge_tx, n).await,
                    SourceConfig::Tcp { addr } => tcp_forever(addr, bridge_tx, n).await,
                }
            });
        })
        .expect("spawn telemetry-source thread");
}

fn forward(mut t: RawTelemetry, bridge_tx: &Sender<BridgeMsg>, n: &Notifier) {
    t.received_at_ms = now_ms();
    n.send(AppEvent::RawPacket { seq: t.seq });
    let _ = bridge_tx.send(BridgeMsg::Sample(t));
}

// ---------------------------------------------------------------------------
// BLE
// ---------------------------------------------------------------------------

async fn ble_forever(
    name_filter: Option<String>,
    scan_timeout: Duration,
    bridge_tx: Sender<BridgeMsg>,
    n: Notifier,
) {
    loop {
        match ble_session(name_filter.as_deref(), scan_timeout, &bridge_tx, &n).await {
            Ok(()) => n.link(LinkState::Disconnected(
                "Bio-chip link lost - rescanning…".into(),
            )),
            Err(e) => {
                n.log(format!("[BLE] {e:#}"));
                n.link(LinkState::Error(format!("{e:#}")));
            }
        }
        tokio::time::sleep(RECONNECT_DELAY).await;
    }
}

async fn ble_session(
    name_filter: Option<&str>,
    scan_timeout: Duration,
    bridge_tx: &Sender<BridgeMsg>,
    n: &Notifier,
) -> Result<()> {
    let manager = Manager::new().await.context("BLE manager init failed")?;
    let adapter = manager
        .adapters()
        .await?
        .into_iter()
        .next()
        .context("No Bluetooth adapter found - is Bluetooth switched on?")?;

    n.link(LinkState::Scanning);
    n.log(format!(
        "[BLE] Scanning for service {SERVICE_UUID}{}",
        name_filter
            .map(|f| format!(" or name containing '{f}'"))
            .unwrap_or_default()
    ));
    // Unfiltered scan: some Windows drivers don't apply service filters to
    // scan-response data, so we match manually below.
    adapter.start_scan(ScanFilter::default()).await?;
    let found = find_biochip(&adapter, name_filter, scan_timeout).await;
    let _ = adapter.stop_scan().await;
    let (peripheral, label) = found?;

    n.link(LinkState::Connecting(label.clone()));
    n.log(format!("[BLE] Found bio-chip '{label}', connecting…"));
    if !peripheral.is_connected().await.unwrap_or(false) {
        tokio::time::timeout(Duration::from_secs(20), peripheral.connect())
            .await
            .context("BLE connect timed out after 20 s")?
            .context("BLE connect failed")?;
    }
    peripheral
        .discover_services()
        .await
        .context("GATT service discovery failed")?;

    let ch = peripheral
        .characteristics()
        .into_iter()
        .find(|c| c.uuid == TELEMETRY_CHAR_UUID)
        .context("Telemetry characteristic not found on device (wrong firmware?)")?;
    if !ch.properties.contains(CharPropFlags::NOTIFY) {
        bail!("Telemetry characteristic does not support NOTIFY");
    }

    let mut stream = peripheral.notifications().await?;
    peripheral
        .subscribe(&ch)
        .await
        .context("Subscribing to notifications failed")?;

    // Extended vitals (radiation / isolation / gravity / environment) are optional:
    // an older simulator without this characteristic still works for core vitals.
    let ext_ch = peripheral
        .characteristics()
        .into_iter()
        .find(|c| c.uuid == EXT_CHAR_UUID);
    match &ext_ch {
        Some(c) => match peripheral.subscribe(c).await {
            Ok(()) => n.log("[BLE] Subscribed to extended-vitals characteristic"),
            Err(e) => n.log(format!(
                "[BLE] Extended vitals unavailable (subscribe failed: {e})"
            )),
        },
        None => n.log(
            "[BLE] Extended-vitals characteristic not found (older simulator): core vitals only",
        ),
    }
    let mut ext_state = ExtendedVitals::default();

    n.link(LinkState::Connected {
        peer: label.clone(),
        transport: "BLE",
    });
    n.log(format!("[BLE] Subscribed to telemetry on '{label}'"));

    loop {
        match tokio::time::timeout(STALL_TIMEOUT, stream.next()).await {
            Ok(Some(notif)) => {
                if notif.uuid == EXT_CHAR_UUID {
                    match decode_ext_frame(&notif.value) {
                        Ok(f) => ext_state.apply_group(f.group, f.values),
                        Err(e) => n.log(format!("[BLE] Dropped bad extended frame: {e}")),
                    }
                    continue;
                }
                if notif.uuid != TELEMETRY_CHAR_UUID {
                    continue;
                }
                match decode_frame(&notif.value) {
                    Ok(mut t) => {
                        // Attach the last known extended values (each group updates
                        // at its own rate; the analysis engine copes with staleness).
                        t.ext = ext_state.clone();
                        forward(t, bridge_tx, n)
                    }
                    Err(e) => n.log(format!("[BLE] Dropped bad frame: {e}")),
                }
            }
            Ok(None) => break, // notification stream closed (disconnect)
            Err(_) => {
                if !peripheral.is_connected().await.unwrap_or(false) {
                    break;
                }
                n.log("[BLE] No telemetry for 5 s (still connected) - waiting…");
            }
        }
    }
    let _ = peripheral.disconnect().await;
    Ok(())
}

async fn find_biochip(
    adapter: &Adapter,
    name_filter: Option<&str>,
    timeout: Duration,
) -> Result<(Peripheral, String)> {
    let deadline = Instant::now() + timeout;
    let filter = name_filter.map(|f| f.to_lowercase());
    loop {
        for p in adapter.peripherals().await? {
            let Ok(Some(props)) = p.properties().await else {
                continue;
            };
            let name = props.local_name.clone().unwrap_or_default();
            let addr = p.address().to_string();
            let svc_match = props.services.contains(&SERVICE_UUID);
            let name_match = filter.as_ref().is_some_and(|f| {
                !f.is_empty()
                    && (name.to_lowercase().contains(f) || addr.to_lowercase().contains(f))
            });
            if svc_match || name_match {
                let label = if name.is_empty() {
                    addr
                } else {
                    format!("{name} [{addr}]")
                };
                return Ok((p, label));
            }
        }
        if Instant::now() >= deadline {
            bail!(
                "No bio-chip found after {} s of scanning. Is the simulator running in BLE mode on Computer 1?",
                timeout.as_secs()
            );
        }
        tokio::time::sleep(Duration::from_millis(750)).await;
    }
}

// ---------------------------------------------------------------------------
// TCP loopback
// ---------------------------------------------------------------------------

async fn tcp_forever(addr: String, bridge_tx: Sender<BridgeMsg>, n: Notifier) {
    loop {
        n.link(LinkState::Connecting(addr.clone()));
        match TcpStream::connect(&addr).await {
            Ok(stream) => {
                let _ = stream.set_nodelay(true);
                n.link(LinkState::Connected {
                    peer: addr.clone(),
                    transport: "TCP loopback",
                });
                n.log(format!("[TCP] Connected to bio-chip simulator at {addr}"));
                let mut lines = BufReader::new(stream).lines();
                let reason = loop {
                    match tokio::time::timeout(STALL_TIMEOUT, lines.next_line()).await {
                        Ok(Ok(Some(line))) => {
                            if line.trim().is_empty() {
                                continue;
                            }
                            match serde_json::from_str::<RawTelemetry>(&line) {
                                Ok(t) => forward(t, &bridge_tx, &n),
                                Err(e) => n.log(format!("[TCP] Bad JSON line: {e}")),
                            }
                        }
                        Ok(Ok(None)) => break "simulator closed the connection".to_string(),
                        Ok(Err(e)) => break format!("socket error: {e}"),
                        Err(_) => n.log("[TCP] No telemetry for 5 s - waiting…"),
                    }
                };
                n.link(LinkState::Disconnected(format!("TCP link lost ({reason})")));
            }
            Err(e) => n.link(LinkState::Error(format!(
                "Cannot reach simulator at {addr}: {e}. Start it with `--mode tcp`."
            ))),
        }
        tokio::time::sleep(RECONNECT_DELAY).await;
    }
}
