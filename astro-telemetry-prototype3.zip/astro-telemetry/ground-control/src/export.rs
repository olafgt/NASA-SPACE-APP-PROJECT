//! "Export Session" -> CSV file with every processed (enriched) sample.
//!
//! Columns: timestamp/sequence, the six core vitals (raw + rolling average + status),
//! overall status and alert text, the 36 extended vitals, the 19 feature levels,
//! the 4 hazard scores and the key derived metrics (dose, cancer risk, bone/lean change...).

use crate::model::Enriched;
use anyhow::{Context, Result};
use chrono::{DateTime, Local, SecondsFormat};
use std::path::{Path, PathBuf};
use telemetry_protocol::ExtendedVitals;

/// Order must match `ext_analysis.FEATURE_IDS`.
pub const FEATURE_IDS: [&str; 19] = [
    "rad_immune",
    "rad_cardio",
    "rad_cns",
    "rad_cancer",
    "iso_sleep",
    "iso_mood",
    "iso_cognition",
    "iso_workload",
    "iso_confinement",
    "iso_reporting",
    "grav_bone",
    "grav_muscle",
    "grav_fluid",
    "grav_cv",
    "grav_loading",
    "grav_nutrition",
    "env_immune",
    "env_resp",
    "env_infection",
];
pub const HAZARD_IDS: [&str; 4] = ["radiation", "isolation", "gravity", "environment"];
/// Derived metrics exported from `Enriched.metrics` (blank when absent).
pub const METRIC_KEYS: [&str; 18] = [
    "mission_day",
    "cumulative_dose_msv",
    "cancer_risk_pct",
    "career_limit_pct",
    "lymphocyte_decline_pct",
    "sleep_debt_h",
    "bmd_loss_pct_month",
    "bmd_change_pct",
    "lean_change_pct",
    "lean_loss_pct_week",
    "orthostatic_rise_bpm",
    "immune_index",
    "infection_score",
    "workload_index",
    "mech_load_pct",
    "vitamin_d_ngml",
    "report_delay_h",
    "composite_risk",
];

const CORE_HEADER: [&str; 22] = [
    "timestamp_utc",
    "seq",
    "elapsed_s",
    "heart_rate_bpm",
    "spo2_pct",
    "core_temp_c",
    "bp_systolic_mmhg",
    "bp_diastolic_mmhg",
    "radiation_usv_h",
    "avg_heart_rate_bpm",
    "avg_spo2_pct",
    "avg_core_temp_c",
    "avg_bp_systolic_mmhg",
    "avg_bp_diastolic_mmhg",
    "avg_radiation_usv_h",
    "status_heart_rate",
    "status_spo2",
    "status_core_temp",
    "status_bp_systolic",
    "status_bp_diastolic",
    "status_radiation",
    "overall_status",
];

/// Full header, in the same order `row()` writes values.
pub fn header() -> Vec<String> {
    let mut h: Vec<String> = CORE_HEADER.iter().map(|s| s.to_string()).collect();
    h.extend(
        [
            "anomaly_score",
            "cumulative_dose_usv",
            "projected_daily_dose_msv",
        ]
        .map(String::from),
    );
    h.extend(
        ExtendedVitals::default()
            .pairs()
            .iter()
            .map(|(n, _)| format!("ext_{n}")),
    );
    h.extend(FEATURE_IDS.iter().map(|f| format!("level_{f}")));
    h.extend(FEATURE_IDS.iter().map(|f| format!("risk_{f}")));
    h.extend(HAZARD_IDS.iter().map(|f| format!("hazard_score_{f}")));
    h.extend(METRIC_KEYS.iter().map(|m| format!("metric_{m}")));
    h.push("alerts".into());
    h
}

fn row(e: &Enriched, t0: u64) -> Vec<String> {
    let ts = DateTime::from_timestamp_millis(e.received_at_ms as i64)
        .map(|d| d.to_rfc3339_opts(SecondsFormat::Millis, true))
        .unwrap_or_default();
    let alerts = e
        .alerts
        .iter()
        .map(|a| format!("{}[{}] {}", a.code, a.level.as_str(), a.message))
        .collect::<Vec<_>>()
        .join(" | ");
    let (r, a, s) = (&e.raw, &e.avg, &e.status);
    let mut v: Vec<String> = vec![
        ts,
        e.seq.to_string(),
        format!("{:.3}", e.received_at_ms.saturating_sub(t0) as f64 / 1000.0),
        format!("{:.1}", r.heart_rate_bpm),
        format!("{:.1}", r.spo2_pct),
        format!("{:.2}", r.core_temp_c),
        format!("{:.0}", r.bp_systolic_mmhg),
        format!("{:.0}", r.bp_diastolic_mmhg),
        format!("{:.1}", r.radiation_usv_h),
        format!("{:.2}", a.heart_rate_bpm),
        format!("{:.2}", a.spo2_pct),
        format!("{:.3}", a.core_temp_c),
        format!("{:.1}", a.bp_systolic_mmhg),
        format!("{:.1}", a.bp_diastolic_mmhg),
        format!("{:.2}", a.radiation_usv_h),
        s.heart_rate_bpm.as_str().into(),
        s.spo2_pct.as_str().into(),
        s.core_temp_c.as_str().into(),
        s.bp_systolic_mmhg.as_str().into(),
        s.bp_diastolic_mmhg.as_str().into(),
        s.radiation_usv_h.as_str().into(),
        e.overall.as_str().into(),
        format!("{:.2}", e.anomaly_score),
        format!("{:.4}", e.cumulative_dose_usv),
        format!("{:.4}", e.projected_daily_dose_msv),
    ];
    // Extended raw values (blank when the simulator sent none).
    let has_ext = e.ext.groups_mask != 0;
    for (_, val) in e.ext.pairs() {
        v.push(if has_ext {
            format!("{val}")
        } else {
            String::new()
        });
    }
    let find = |id: &str| e.features.iter().find(|f| f.id == id);
    for id in FEATURE_IDS {
        v.push(
            find(id)
                .filter(|f| f.has_data)
                .map(|f| f.level.as_str().to_string())
                .unwrap_or_default(),
        );
    }
    for id in FEATURE_IDS {
        v.push(
            find(id)
                .filter(|f| f.has_data)
                .map(|f| format!("{:.1}", f.risk))
                .unwrap_or_default(),
        );
    }
    for id in HAZARD_IDS {
        v.push(
            e.hazards
                .iter()
                .find(|h| h.id == id)
                .map(|h| format!("{:.1}", h.score))
                .unwrap_or_default(),
        );
    }
    for k in METRIC_KEYS {
        v.push(e.metrics.get(k).map(|x| format!("{x}")).unwrap_or_default());
    }
    v.push(alerts);
    v
}

/// Write the session to `<dir>/session_YYYYmmdd_HHMMSS.csv` and return the path.
pub fn export_session(history: &[Enriched], dir: &Path) -> Result<PathBuf> {
    std::fs::create_dir_all(dir)
        .with_context(|| format!("cannot create export folder {}", dir.display()))?;
    let path = dir.join(format!(
        "session_{}.csv",
        Local::now().format("%Y%m%d_%H%M%S")
    ));
    let mut w = csv::Writer::from_path(&path)
        .with_context(|| format!("cannot create {}", path.display()))?;
    w.write_record(header())?;
    let t0 = history.first().map(|e| e.received_at_ms).unwrap_or(0);
    for e in history {
        w.write_record(row(e, t0))?;
    }
    w.flush()?;
    Ok(path)
}

/// Open a folder in the OS file manager (Explorer on Windows).
pub fn open_folder(dir: &Path) {
    let _ = std::fs::create_dir_all(dir);
    #[cfg(windows)]
    let cmd = "explorer";
    #[cfg(target_os = "macos")]
    let cmd = "open";
    #[cfg(all(unix, not(target_os = "macos")))]
    let cmd = "xdg-open";
    let _ = std::process::Command::new(cmd).arg(dir).spawn();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn header_and_row_have_equal_length() {
        let e = Enriched::default();
        assert_eq!(header().len(), row(&e, 0).len());
    }
}
