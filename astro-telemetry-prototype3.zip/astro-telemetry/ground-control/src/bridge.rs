//! Rust ⇄ Python IPC bridge.
//!
//! Spawns `analysis.py` as a background child process and talks JSON Lines:
//!   Rust → Python (stdin):  one `RawTelemetry` object per line (or `{"cmd":"reset"}`)
//!   Python → Rust (stdout): `{"type":"ready"|"telemetry"|"reset", ...}` per line
//!   Python stderr          → dashboard system log
//!
//! A supervisor thread restarts the interpreter automatically if it crashes or
//! is killed, so a Python bug never takes down Ground Control.

use crate::model::{AnalysisState, AppEvent, BridgeMsg, Notifier, PyMessage};
use anyhow::{Context, Result};
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::PathBuf;
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::mpsc::{Receiver, RecvTimeoutError};
use std::thread;
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct PythonConfig {
    /// Explicit interpreter (e.g. `C:\Python312\python.exe`). If `None`, we try
    /// `python`, then `py -3`, then `python3`.
    pub interpreter: Option<String>,
    pub script: PathBuf,
    /// Extra args forwarded to analysis.py (`--window 30` …).
    pub script_args: Vec<String>,
}

/// Candidate (program, leading args) pairs to try when launching Python.
fn interpreter_candidates(cfg: &PythonConfig) -> Vec<(String, Vec<String>)> {
    match &cfg.interpreter {
        Some(p) => vec![(p.clone(), vec![])],
        None => vec![
            ("python".into(), vec![]),
            ("py".into(), vec!["-3".into()]),
            ("python3".into(), vec![]),
        ],
    }
}

fn start_child(cfg: &PythonConfig) -> Result<(Child, String)> {
    if !cfg.script.exists() {
        anyhow::bail!(
            "analysis script not found at {} (use --script <path>)",
            cfg.script.display()
        );
    }
    let mut last_err = None;
    for (program, pre) in interpreter_candidates(cfg) {
        let mut cmd = Command::new(&program);
        cmd.args(&pre)
            .arg("-u") // unbuffered stdio: no lines stuck in Python's buffers
            .arg(&cfg.script)
            .args(&cfg.script_args)
            .env("PYTHONIOENCODING", "utf-8")
            .env("PYTHONUNBUFFERED", "1")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());

        #[cfg(windows)]
        {
            use std::os::windows::process::CommandExt;
            const CREATE_NO_WINDOW: u32 = 0x0800_0000;
            cmd.creation_flags(CREATE_NO_WINDOW);
        }

        match cmd.spawn() {
            Ok(mut child) => {
                // Windows' "App execution alias" python.exe (Microsoft Store stub)
                // spawns fine but exits immediately. Detect that and fall through
                // to the next candidate (`py -3`).
                thread::sleep(Duration::from_millis(400));
                if let Ok(Some(status)) = child.try_wait() {
                    last_err = Some(format!("{program} exited immediately ({status})"));
                    continue;
                }
                let desc = format!("{program} {}", pre.join(" ")).trim().to_string();
                return Ok((child, desc));
            }
            Err(e) => last_err = Some(format!("{program}: {e}")),
        }
    }
    anyhow::bail!(
        "could not start a Python interpreter ({}). Install Python 3.8+ and make sure \
         `python` is on PATH, or pass --python <path-to-python.exe>",
        last_err.unwrap_or_default()
    )
}

fn write_line(w: &mut BufWriter<ChildStdin>, line: &str) -> std::io::Result<()> {
    w.write_all(line.as_bytes())?;
    w.write_all(b"\n")?;
    w.flush()
}

/// Start the supervisor thread. Returns immediately.
pub fn spawn(cfg: PythonConfig, rx: Receiver<BridgeMsg>, n: Notifier) {
    thread::Builder::new()
        .name("python-bridge".into())
        .spawn(move || supervise(cfg, rx, n))
        .expect("spawn python-bridge thread");
}

fn supervise(cfg: PythonConfig, rx: Receiver<BridgeMsg>, n: Notifier) {
    loop {
        n.send(AppEvent::Analysis(AnalysisState::Starting));
        let (mut child, desc) = match start_child(&cfg) {
            Ok(c) => c,
            Err(e) => {
                n.send(AppEvent::Analysis(AnalysisState::Failed(format!("{e:#}"))));
                n.log(format!("[PY] {e:#}"));
                // Drop queued samples while Python is unavailable (no unbounded backlog).
                let deadline = std::time::Instant::now() + Duration::from_secs(5);
                while std::time::Instant::now() < deadline {
                    if let Err(RecvTimeoutError::Disconnected) =
                        rx.recv_timeout(Duration::from_millis(200))
                    {
                        return;
                    }
                }
                continue;
            }
        };

        let pid = child.id();
        n.log(format!("[PY] Started analysis engine: {desc} (pid {pid})"));

        // --- stdout reader: enriched telemetry → UI -------------------------
        let stdout = child.stdout.take().expect("piped stdout");
        let n_out = n.clone();
        let desc_out = desc.clone();
        let _ = thread::Builder::new()
            .name("python-stdout".into())
            .spawn(move || {
                for line in BufReader::new(stdout).lines() {
                    let Ok(line) = line else { break };
                    if line.trim().is_empty() {
                        continue;
                    }
                    match serde_json::from_str::<PyMessage>(&line) {
                        Ok(PyMessage::Telemetry(e)) => n_out.send(AppEvent::Telemetry(Box::new(e))),
                        Ok(PyMessage::Ready {
                            version,
                            python,
                            window,
                            extended,
                        }) => n_out.send(AppEvent::Analysis(AnalysisState::Running {
                            pid,
                            detail: format!(
                                "analysis.py v{version} on Python {python} ({desc_out}), window {window}, extended hazards {}",
                                if extended { "on" } else { "OFF (ext_analysis.py missing?)" }
                            ),
                        })),
                        Ok(PyMessage::Reset) => n_out.send(AppEvent::AnalysisReset),
                        Err(e) => n_out.log(format!("[PY] Unparseable output ({e}): {line}")),
                    }
                }
            });

        // --- stderr reader: diagnostics → system log ------------------------
        let stderr = child.stderr.take().expect("piped stderr");
        let n_err = n.clone();
        let _ = thread::Builder::new()
            .name("python-stderr".into())
            .spawn(move || {
                for line in BufReader::new(stderr).lines().map_while(|l| l.ok()) {
                    n_err.log(format!("[PY] {line}"));
                }
            });

        // --- stdin writer: raw telemetry → Python ---------------------------
        let mut stdin = BufWriter::new(child.stdin.take().expect("piped stdin"));
        let reason = loop {
            match rx.recv_timeout(Duration::from_millis(500)) {
                Ok(msg) => {
                    let line = match msg {
                        BridgeMsg::Sample(s) => match serde_json::to_string(&s) {
                            Ok(l) => l,
                            Err(e) => {
                                n.log(format!("[PY] serialise error: {e}"));
                                continue;
                            }
                        },
                        BridgeMsg::Reset => r#"{"cmd":"reset"}"#.to_string(),
                    };
                    if let Err(e) = write_line(&mut stdin, &line) {
                        break format!("pipe write failed: {e}");
                    }
                }
                Err(RecvTimeoutError::Timeout) => {
                    if let Ok(Some(status)) = child.try_wait() {
                        break format!("process exited ({status})");
                    }
                }
                Err(RecvTimeoutError::Disconnected) => {
                    // App is shutting down.
                    let _ = child.kill();
                    let _ = child.wait();
                    return;
                }
            }
        };

        let _ = child.kill();
        let _ = child.wait();
        let msg = format!("Analysis engine stopped: {reason}. Restarting in 2 s…");
        n.log(format!("[PY] {msg}"));
        n.send(AppEvent::Analysis(AnalysisState::Failed(msg)));
        thread::sleep(Duration::from_secs(2));
    }
}

/// Locate analysis.py: explicit path → next to the .exe → ./python → crate dir.
pub fn resolve_script(explicit: Option<PathBuf>) -> PathBuf {
    if let Some(p) = explicit {
        return p;
    }
    let mut candidates: Vec<PathBuf> = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            candidates.push(dir.join("python").join("analysis.py"));
        }
    }
    candidates.push(PathBuf::from("python").join("analysis.py"));
    candidates.push(
        PathBuf::from("ground-control")
            .join("python")
            .join("analysis.py"),
    );
    candidates.push(
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("python")
            .join("analysis.py"),
    );
    candidates
        .iter()
        .find(|p| p.exists())
        .cloned()
        .unwrap_or_else(|| candidates.last().cloned().unwrap())
}

/// Convenience used by `main`: validate early so the user sees a clear message.
pub fn check_script(path: &std::path::Path) -> Result<()> {
    std::fs::metadata(path)
        .with_context(|| format!("analysis.py not found at {}", path.display()))
        .map(|_| ())
}
