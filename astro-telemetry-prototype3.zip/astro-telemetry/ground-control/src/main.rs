//! # COMPUTER 2 — Ground Control Center
//!
//! ```text
//!  ┌──────────────┐  BLE notify (18-byte frames)   ┌──────────────────────────────┐
//!  │ Computer 1   │ ─────────────────────────────► │ source.rs (btleplug, tokio)  │
//!  │ bio-chip-sim │   or TCP JSON lines (loopback) └──────────────┬───────────────┘
//!  └──────────────┘                                     RawTelemetry│ mpsc
//!                                                                  ▼
//!                       stdin JSONL  ┌───────────────┐  ┌──────────────────────────┐
//!                     ◄───────────── │ analysis.py   │  │ bridge.rs (child process │
//!                     ─────────────► │ (Python)      │  │ supervisor, JSONL IPC)   │
//!                      stdout JSONL  └───────────────┘  └──────────────┬───────────┘
//!                                                     Enriched (mpsc) │
//!                                                                  ▼
//!                               app.rs (eframe/egui + egui_plot) ── export.rs (CSV)
//! ```

mod app;
mod bridge;
mod export;
mod model;
mod source;

use clap::{Parser, ValueEnum};
use model::{AppEvent, BridgeMsg, Notifier};
use std::path::PathBuf;
use std::sync::mpsc;
use std::time::Duration;
use telemetry_protocol::DEFAULT_TCP_ADDR;

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
enum Source {
    /// Bluetooth Low Energy (btleplug, native WinRT backend).
    Ble,
    /// Local Mock/Loopback: TCP JSON lines from `bio-chip-sim --mode tcp`.
    Tcp,
}

#[derive(Debug, Parser)]
#[command(
    name = "ground-control",
    version,
    about = "COMPUTER 2: Ground Control Center - astronaut bio-telemetry dashboard"
)]
struct Args {
    /// Where telemetry comes from.
    #[arg(long, value_enum, default_value_t = Source::Ble)]
    source: Source,

    /// TCP address of the simulator in loopback mode.
    #[arg(long, default_value = DEFAULT_TCP_ADDR)]
    addr: String,

    /// BLE: also accept a device whose advertised name/address contains this text.
    #[arg(long)]
    device_name: Option<String>,

    /// BLE: seconds to scan before reporting "not found" and retrying.
    #[arg(long, default_value_t = 30)]
    scan_timeout: u64,

    /// Python interpreter (default: tries `python`, `py -3`, `python3`).
    #[arg(long)]
    python: Option<String>,

    /// Path to analysis.py (default: auto-detected).
    #[arg(long)]
    script: Option<PathBuf>,

    /// Rolling window size passed to analysis.py.
    #[arg(long, default_value_t = 30)]
    window: u32,

    /// Consecutive samples before a WARNING alarms (CRITICAL is immediate).
    #[arg(long, default_value_t = 2)]
    persistence: u32,

    /// z-score that flags a RAPID_CHANGE anomaly.
    #[arg(long, default_value_t = 4.5)]
    z_threshold: f64,

    /// Career effective-dose limit (mSv) used by the cancer-risk gauge.
    #[arg(long, default_value_t = 600.0)]
    career_limit_msv: f64,

    /// Folder for "Export Session" CSV files.
    #[arg(long, default_value = "exports")]
    export_dir: PathBuf,
}

fn main() -> eframe::Result<()> {
    let args = Args::parse();

    let script = bridge::resolve_script(args.script.clone());
    let script_problem = bridge::check_script(&script)
        .err()
        .map(|e| format!("{e:#}"));

    let py_cfg = bridge::PythonConfig {
        interpreter: args.python.clone(),
        script,
        script_args: vec![
            "--window".into(),
            args.window.to_string(),
            "--persistence".into(),
            args.persistence.to_string(),
            "--z-threshold".into(),
            args.z_threshold.to_string(),
            "--career-limit-msv".into(),
            args.career_limit_msv.to_string(),
        ],
    };

    let (src_cfg, source_label) = match args.source {
        Source::Ble => (
            source::SourceConfig::Ble {
                name_filter: args.device_name.clone(),
                scan_timeout: Duration::from_secs(args.scan_timeout.max(5)),
            },
            "Bluetooth LE".to_string(),
        ),
        Source::Tcp => (
            source::SourceConfig::Tcp {
                addr: args.addr.clone(),
            },
            format!("TCP loopback {}", args.addr),
        ),
    };

    let export_dir = if args.export_dir.is_absolute() {
        args.export_dir.clone()
    } else {
        std::env::current_dir()
            .unwrap_or_default()
            .join(&args.export_dir)
    };

    let options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_title("Ground Control — Astronaut Bio-Telemetry")
            .with_inner_size([1440.0, 900.0])
            .with_min_inner_size([1000.0, 650.0]),
        ..Default::default()
    };

    eframe::run_native(
        "ground-control",
        options,
        Box::new(move |cc| {
            // Channels: source → bridge (raw), everyone → UI (events).
            let (bridge_tx, bridge_rx) = mpsc::channel::<BridgeMsg>();
            let (ui_tx, ui_rx) = mpsc::channel::<AppEvent>();
            let notifier = Notifier::new(ui_tx, cc.egui_ctx.clone());

            if let Some(p) = script_problem {
                notifier.log(format!("[PY] {p}"));
            }
            bridge::spawn(py_cfg, bridge_rx, notifier.clone());
            source::spawn(src_cfg, bridge_tx.clone(), notifier.clone());

            Ok(Box::new(app::GroundControlApp::new(
                cc,
                ui_rx,
                bridge_tx,
                source_label,
                export_dir,
            )))
        }),
    )
}
