//! Data types flowing between the BLE/TCP source, the Python bridge and the UI.

use serde::Deserialize;
use std::collections::HashMap;
use telemetry_protocol::{ExtendedVitals, RawTelemetry};

/// Alert severity, as computed by `analysis.py`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum Level {
    #[default]
    Nominal,
    Warning,
    Critical,
}

impl Level {
    pub fn as_str(self) -> &'static str {
        match self {
            Level::Nominal => "NOMINAL",
            Level::Warning => "WARNING",
            Level::Critical => "CRITICAL",
        }
    }
}

/// One f64 per vital sign (raw values, averages, trends, z-scores).
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct VitalValues {
    pub heart_rate_bpm: f64,
    pub spo2_pct: f64,
    pub core_temp_c: f64,
    pub bp_systolic_mmhg: f64,
    pub bp_diastolic_mmhg: f64,
    pub radiation_usv_h: f64,
}

/// One status level per vital sign.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct VitalLevels {
    pub heart_rate_bpm: Level,
    pub spo2_pct: Level,
    pub core_temp_c: Level,
    pub bp_systolic_mmhg: Level,
    pub bp_diastolic_mmhg: Level,
    pub radiation_usv_h: Level,
}

#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct Alert {
    pub vital: String,
    pub level: Level,
    pub code: String,
    pub message: String,
}

impl Alert {
    /// Identity used to detect when an alert starts / escalates / clears.
    pub fn key(&self) -> String {
        format!("{}:{}:{}", self.vital, self.code, self.level.as_str())
    }
}

/// One of the 19 hazard features evaluated by `ext_analysis.py`.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct Feature {
    pub id: String,
    /// radiation | isolation | gravity | environment
    pub group: String,
    pub name: String,
    pub level: Level,
    /// 0-100 (<30 nominal, 30-65 warning, >65 critical)
    pub risk: f64,
    pub value: String,
    pub detail: String,
    pub has_data: bool,
    /// Recommended response (from the resolution plan); empty while nominal.
    #[serde(default)]
    pub action: String,
}

/// Roll-up of the features in one hazard group.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct Hazard {
    pub id: String,
    pub name: String,
    pub level: Level,
    pub score: f64,
}

/// A telemetry sample enriched by the Python analysis engine.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default)]
pub struct Enriched {
    pub seq: u32,
    pub received_at_ms: u64,
    pub raw: VitalValues,
    pub avg: VitalValues,
    pub trend_per_min: VitalValues,
    pub zscore: VitalValues,
    pub status: VitalLevels,
    pub overall: Level,
    pub alerts: Vec<Alert>,
    pub cumulative_dose_usv: f64,
    pub projected_daily_dose_msv: f64,
    pub anomaly_score: f64,
    pub window: usize,
    pub processing_us: f64,
    /// Raw extended vitals echoed back by the engine (empty on old simulators).
    pub ext: ExtendedVitals,
    pub features: Vec<Feature>,
    pub hazards: Vec<Hazard>,
    /// mission_day, cumulative_dose_msv, cancer_risk_pct, bmd_change_pct, composite_risk ...
    pub metrics: HashMap<String, f64>,
}

impl Enriched {
    pub fn metric(&self, key: &str) -> f64 {
        self.metrics.get(key).copied().unwrap_or(0.0)
    }
}

/// Lines the Python engine writes to stdout.
#[derive(Debug, Deserialize)]
#[serde(tag = "type", rename_all = "lowercase")]
pub enum PyMessage {
    Ready {
        #[serde(default)]
        version: String,
        #[serde(default)]
        python: String,
        #[serde(default)]
        window: usize,
        #[serde(default)]
        extended: bool,
    },
    Telemetry(Enriched),
    Reset,
}

/// Messages into the Python bridge.
#[derive(Debug, Clone)]
pub enum BridgeMsg {
    Sample(RawTelemetry),
    /// Clear rolling windows and cumulative dose.
    Reset,
}

/// State of the radio / loopback link.
#[derive(Debug, Clone)]
pub enum LinkState {
    Idle,
    Scanning,
    Connecting(String),
    Connected {
        peer: String,
        transport: &'static str,
    },
    Disconnected(String),
    Error(String),
}

/// State of the Python child process.
#[derive(Debug, Clone)]
pub enum AnalysisState {
    Starting,
    Running { pid: u32, detail: String },
    Failed(String),
}

/// Everything the background threads tell the UI.
#[derive(Debug)]
pub enum AppEvent {
    Link(LinkState),
    Analysis(AnalysisState),
    /// A raw packet arrived from the link (counted even if Python is down).
    RawPacket {
        seq: u32,
    },
    Telemetry(Box<Enriched>),
    AnalysisReset,
    Log(String),
}

/// Sends `AppEvent`s to the UI and wakes the egui event loop.
#[derive(Clone)]
pub struct Notifier {
    tx: std::sync::mpsc::Sender<AppEvent>,
    ctx: eframe::egui::Context,
}

impl Notifier {
    pub fn new(tx: std::sync::mpsc::Sender<AppEvent>, ctx: eframe::egui::Context) -> Self {
        Self { tx, ctx }
    }
    pub fn send(&self, ev: AppEvent) {
        let _ = self.tx.send(ev);
        self.ctx.request_repaint();
    }
    pub fn link(&self, s: LinkState) {
        self.send(AppEvent::Link(s));
    }
    pub fn log(&self, msg: impl Into<String>) {
        self.send(AppEvent::Log(msg.into()));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Real lines produced by python/analysis.py (ready + two telemetry samples):
    /// guards the Rust <-> Python JSON contract.
    #[test]
    fn parses_real_engine_output() {
        let data = include_str!("../testdata/engine_output_sample.jsonl");
        let mut telemetry = 0;
        for line in data.lines().filter(|l| !l.trim().is_empty()) {
            match serde_json::from_str::<PyMessage>(line).expect(line) {
                PyMessage::Ready { extended, .. } => assert!(extended),
                PyMessage::Telemetry(e) => {
                    telemetry += 1;
                    assert_eq!(e.features.len(), 19, "all 19 features present");
                    assert_eq!(e.hazards.len(), 4);
                    assert!(e.metric("mission_day") > 0.0);
                    assert!(e.ext.groups_mask == 0b111111);
                    assert!(e
                        .features
                        .iter()
                        .all(|f| !f.id.is_empty() && !f.group.is_empty()));
                }
                PyMessage::Reset => {}
            }
        }
        assert_eq!(telemetry, 2);
    }
}
