//! egui dashboard: live vitals, colour-coded alerts, scrolling charts, CSV export.

use crate::export;
use crate::model::{
    Alert, AnalysisState, AppEvent, BridgeMsg, Enriched, Feature, Hazard, Level, LinkState,
};
use eframe::egui::{self, Align, Color32, Frame, Layout, Margin, RichText, ScrollArea, Stroke};
use egui_plot::{HLine, Legend, Line, LineStyle, Plot, PlotPoints};
use std::collections::{HashMap, VecDeque};
use std::path::PathBuf;
use std::sync::mpsc::{Receiver, Sender};
use std::time::{Duration, Instant};
use telemetry_protocol::ext_group_of;

/// Samples kept on screen per chart (5 minutes at 1 Hz).
const PLOT_WINDOW: usize = 300;
/// Without a new packet for this long the link is shown as SIGNAL LOST.
const STALE_AFTER: Duration = Duration::from_secs(5);
const MAX_LOG_LINES: usize = 500;
/// Points kept per extended chart (x axis = mission day, so this covers a long mission).
const EXT_PLOT_WINDOW: usize = 4000;
/// Extended signals charted on the Risk tab.
const EXT_PLOT_KEYS: [&str; 8] = [
    "lymphocytes_per_ul",
    "hrv_rmssd_ms",
    "reaction_time_ms",
    "cabin_co2_mmhg",
    "lean_mass_kg",
    "fluid_index",
    "vitamin_d_ngml",
    "workload_index",
];

#[derive(Clone, Copy, PartialEq, Eq)]
enum Tab {
    Vitals,
    Risk,
}

// Palette -------------------------------------------------------------------
const C_NOMINAL: Color32 = Color32::from_rgb(46, 204, 113);
const C_WARNING: Color32 = Color32::from_rgb(241, 196, 15);
const C_CRITICAL: Color32 = Color32::from_rgb(231, 76, 60);
const C_STALE: Color32 = Color32::from_rgb(127, 140, 141);
const C_ACCENT: Color32 = Color32::from_rgb(52, 152, 219);
const C_PANEL: Color32 = Color32::from_rgb(24, 28, 36);

fn level_color(l: Level) -> Color32 {
    match l {
        Level::Nominal => C_NOMINAL,
        Level::Warning => C_WARNING,
        Level::Critical => C_CRITICAL,
    }
}

/// Rolling chart buffers, x = seconds since session start.
#[derive(Default)]
struct Series {
    hr: VecDeque<[f64; 2]>,
    hr_avg: VecDeque<[f64; 2]>,
    spo2: VecDeque<[f64; 2]>,
    temp: VecDeque<[f64; 2]>,
    sys: VecDeque<[f64; 2]>,
    dia: VecDeque<[f64; 2]>,
    rad: VecDeque<[f64; 2]>,
}

impl Series {
    fn push(&mut self, x: f64, e: &Enriched) {
        let push = |q: &mut VecDeque<[f64; 2]>, y: f64| {
            q.push_back([x, y]);
            while q.len() > PLOT_WINDOW {
                q.pop_front();
            }
        };
        push(&mut self.hr, e.raw.heart_rate_bpm);
        push(&mut self.hr_avg, e.avg.heart_rate_bpm);
        push(&mut self.spo2, e.raw.spo2_pct);
        push(&mut self.temp, e.raw.core_temp_c);
        push(&mut self.sys, e.raw.bp_systolic_mmhg);
        push(&mut self.dia, e.raw.bp_diastolic_mmhg);
        push(&mut self.rad, e.raw.radiation_usv_h);
    }
}

fn risk_color(score: f64) -> Color32 {
    if score >= 65.0 {
        C_CRITICAL
    } else if score >= 30.0 {
        C_WARNING
    } else {
        C_NOMINAL
    }
}

struct LogEntry {
    time: String,
    level: Level,
    text: String,
}

pub struct GroundControlApp {
    events: Receiver<AppEvent>,
    bridge_tx: Sender<BridgeMsg>,
    source_label: String,
    export_dir: PathBuf,

    link: LinkState,
    analysis: AnalysisState,

    latest: Option<Enriched>,
    history: Vec<Enriched>,
    series: Series,
    ext_series: HashMap<&'static str, VecDeque<[f64; 2]>>,
    tab: Tab,
    session_start_ms: Option<u64>,

    last_packet: Option<Instant>,
    rx_packets: u64,
    analyzed: u64,
    lost_packets: u64,
    last_seq: Option<u32>,

    /// Alerts currently active (key → alert) for transition detection.
    active: HashMap<String, Alert>,
    alert_log: VecDeque<LogEntry>,
    system_log: VecDeque<String>,
    export_status: Option<(String, bool)>,
}

impl GroundControlApp {
    pub fn new(
        cc: &eframe::CreationContext<'_>,
        events: Receiver<AppEvent>,
        bridge_tx: Sender<BridgeMsg>,
        source_label: String,
        export_dir: PathBuf,
    ) -> Self {
        let mut visuals = egui::Visuals::dark();
        visuals.panel_fill = Color32::from_rgb(16, 19, 26);
        visuals.window_fill = C_PANEL;
        cc.egui_ctx.set_visuals(visuals);

        Self {
            events,
            bridge_tx,
            source_label,
            export_dir,
            link: LinkState::Idle,
            analysis: AnalysisState::Starting,
            latest: None,
            history: Vec::new(),
            series: Series::default(),
            ext_series: HashMap::new(),
            tab: Tab::Vitals,
            session_start_ms: None,
            last_packet: None,
            rx_packets: 0,
            analyzed: 0,
            lost_packets: 0,
            last_seq: None,
            active: HashMap::new(),
            alert_log: VecDeque::new(),
            system_log: VecDeque::new(),
            export_status: None,
        }
    }

    // ------------------------------------------------------------------
    // Event handling
    // ------------------------------------------------------------------

    fn drain_events(&mut self) {
        while let Ok(ev) = self.events.try_recv() {
            match ev {
                AppEvent::Link(s) => {
                    self.sys_log(format!("link: {}", describe_link(&s)));
                    self.link = s;
                }
                AppEvent::Analysis(s) => self.analysis = s,
                AppEvent::RawPacket { seq } => self.on_raw(seq),
                AppEvent::Telemetry(e) => self.on_telemetry(*e),
                AppEvent::AnalysisReset => self.sys_log("analysis engine state reset".into()),
                AppEvent::Log(m) => self.sys_log(m),
            }
        }
    }

    fn on_raw(&mut self, seq: u32) {
        self.rx_packets += 1;
        self.last_packet = Some(Instant::now());
        if let Some(prev) = self.last_seq {
            let expected = prev.wrapping_add(1);
            if seq != expected {
                if seq > prev {
                    self.lost_packets += (seq - expected) as u64;
                } else {
                    self.sys_log(format!(
                        "sequence restarted ({prev} → {seq}): simulator restarted?"
                    ));
                    self.ext_series.clear(); // mission clock restarted too
                }
            }
        }
        self.last_seq = Some(seq);
    }

    fn on_telemetry(&mut self, e: Enriched) {
        self.analyzed += 1;
        let start = *self.session_start_ms.get_or_insert(e.received_at_ms);
        let x = e.received_at_ms.saturating_sub(start) as f64 / 1000.0;
        self.series.push(x, &e);
        self.push_ext_series(&e);

        // Alert transitions → event log.
        let now = chrono::Local::now().format("%H:%M:%S").to_string();
        let mut current: HashMap<String, Alert> = HashMap::new();
        for a in &e.alerts {
            current.insert(a.key(), a.clone());
        }
        for (k, a) in &current {
            if !self.active.contains_key(k) {
                self.push_alert_log(now.clone(), a.level, a.message.clone());
            }
        }
        let cleared: Vec<Alert> = self
            .active
            .iter()
            .filter(|(k, _)| !current.contains_key(*k))
            .map(|(_, a)| a.clone())
            .collect();
        for a in cleared {
            // Only report a clear if the same vital/code isn't still active at another level.
            let still = current
                .values()
                .any(|c| c.vital == a.vital && c.code == a.code);
            if !still {
                self.push_alert_log(
                    now.clone(),
                    Level::Nominal,
                    format!("Cleared: {} on {}", a.code, pretty_vital(&a.vital)),
                );
            }
        }
        self.active = current;

        self.history.push(e.clone());
        self.latest = Some(e);
    }

    fn push_ext_series(&mut self, e: &Enriched) {
        let day = e.metric("mission_day");
        for key in EXT_PLOT_KEYS {
            let Some(g) = ext_group_of(key) else { continue };
            if !e.ext.has_group(g) {
                continue;
            }
            let q = self.ext_series.entry(key).or_default();
            q.push_back([day, e.ext.get(key)]);
            while q.len() > EXT_PLOT_WINDOW {
                q.pop_front();
            }
        }
    }

    fn push_alert_log(&mut self, time: String, level: Level, text: String) {
        self.alert_log.push_front(LogEntry { time, level, text });
        self.alert_log.truncate(MAX_LOG_LINES);
    }

    fn sys_log(&mut self, msg: String) {
        let t = chrono::Local::now().format("%H:%M:%S");
        self.system_log.push_back(format!("{t}  {msg}"));
        while self.system_log.len() > MAX_LOG_LINES {
            self.system_log.pop_front();
        }
    }

    fn clear_session(&mut self) {
        self.history.clear();
        self.series = Series::default();
        self.ext_series.clear();
        self.session_start_ms = None;
        self.latest = None;
        self.active.clear();
        self.alert_log.clear();
        self.rx_packets = 0;
        self.analyzed = 0;
        self.lost_packets = 0;
        self.last_seq = None;
        let _ = self.bridge_tx.send(BridgeMsg::Reset);
        self.sys_log("session cleared".into());
    }

    fn is_stale(&self) -> bool {
        self.last_packet.map_or(true, |t| t.elapsed() > STALE_AFTER)
    }

    // ------------------------------------------------------------------
    // UI pieces
    // ------------------------------------------------------------------

    fn top_bar(&mut self, ui: &mut egui::Ui) {
        ui.horizontal_wrapped(|ui| {
            ui.label(
                RichText::new("GROUND CONTROL")
                    .strong()
                    .size(20.0)
                    .color(C_ACCENT),
            );
            ui.label(RichText::new("Astronaut Bio-Telemetry").size(16.0));
            ui.separator();

            let (txt, col) = match &self.link {
                LinkState::Connected { transport, .. } => (format!("LINK: {transport}"), C_NOMINAL),
                LinkState::Scanning => ("LINK: SCANNING".into(), C_WARNING),
                LinkState::Connecting(_) => ("LINK: CONNECTING".into(), C_WARNING),
                LinkState::Idle => ("LINK: IDLE".into(), C_STALE),
                LinkState::Disconnected(_) => ("LINK: LOST".into(), C_CRITICAL),
                LinkState::Error(_) => ("LINK: ERROR".into(), C_CRITICAL),
            };
            pill(ui, &txt, col).on_hover_text(describe_link(&self.link));

            let (txt, col, tip) = match &self.analysis {
                AnalysisState::Running { pid, detail } => {
                    (format!("PYTHON: ON (pid {pid})"), C_NOMINAL, detail.clone())
                }
                AnalysisState::Starting => ("PYTHON: STARTING".into(), C_WARNING, String::new()),
                AnalysisState::Failed(e) => ("PYTHON: DOWN".into(), C_CRITICAL, e.clone()),
            };
            pill(ui, &txt, col).on_hover_text(tip);

            ui.separator();
            let age = self
                .last_packet
                .map(|t| format!("{:.1}s ago", t.elapsed().as_secs_f32()))
                .unwrap_or_else(|| "never".into());
            ui.label(format!(
                "RX {} | analysed {} | lost {} | last packet {}",
                self.rx_packets, self.analyzed, self.lost_packets, age
            ));

            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                if ui
                    .button("Clear session")
                    .on_hover_text("Discard history and reset the analysis windows")
                    .clicked()
                {
                    self.clear_session();
                }
                if ui
                    .button("Open exports folder")
                    .on_hover_text(self.export_dir.display().to_string())
                    .clicked()
                {
                    export::open_folder(&self.export_dir);
                }
                let export_btn = ui.add_enabled(
                    !self.history.is_empty(),
                    egui::Button::new(
                        RichText::new("Export Session (.csv)")
                            .strong()
                            .color(Color32::WHITE),
                    )
                    .fill(Color32::from_rgb(41, 128, 185)),
                );
                if export_btn.clicked() {
                    self.export_status = Some(
                        match export::export_session(&self.history, &self.export_dir) {
                            Ok(p) => (
                                format!(
                                    "Exported {} samples → {}",
                                    self.history.len(),
                                    p.display()
                                ),
                                true,
                            ),
                            Err(e) => (format!("Export failed: {e:#}"), false),
                        },
                    );
                    let msg = self.export_status.as_ref().map(|(m, _)| m.clone());
                    if let Some(m) = msg {
                        self.sys_log(m);
                    }
                }
            });
        });
        if let Some((msg, ok)) = &self.export_status {
            ui.label(RichText::new(msg).color(if *ok { C_NOMINAL } else { C_CRITICAL }));
        }
    }

    fn status_banner(&self, ui: &mut egui::Ui) {
        let blink = (ui.input(|i| i.time) * 2.5).sin() > 0.0;
        let (text, col) = if self.is_stale() {
            let reason = match &self.link {
                LinkState::Connected { .. } => "no packets received".to_string(),
                other => describe_link(other),
            };
            (format!("SIGNAL LOST — {reason}"), C_STALE)
        } else if let Some(e) = &self.latest {
            let n = e.alerts.len();
            match e.overall {
                Level::Nominal => ("ALL SYSTEMS NOMINAL".to_string(), C_NOMINAL),
                Level::Warning => (format!("CAUTION — {n} active alert(s)"), C_WARNING),
                Level::Critical => (format!("CRITICAL — {n} active alert(s)"), C_CRITICAL),
            }
        } else {
            ("AWAITING TELEMETRY…".to_string(), C_STALE)
        };
        let critical = self
            .latest
            .as_ref()
            .is_some_and(|e| e.overall == Level::Critical)
            && !self.is_stale();
        let fill = if critical && blink {
            col.gamma_multiply(0.55)
        } else {
            col.gamma_multiply(0.25)
        };
        Frame::none()
            .fill(fill)
            .stroke(Stroke::new(2.0, col))
            .rounding(6.0)
            .inner_margin(Margin::symmetric(12.0, 8.0))
            .show(ui, |ui| {
                ui.set_min_width(ui.available_width());
                ui.horizontal(|ui| {
                    ui.label(
                        RichText::new(text)
                            .size(22.0)
                            .strong()
                            .color(Color32::WHITE),
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ui.label(
                            RichText::new(format!("Source: {}", self.source_label))
                                .color(Color32::LIGHT_GRAY),
                        );
                    });
                });
            });
    }

    fn vital_cards(&self, ui: &mut egui::Ui) {
        let stale = self.is_stale();
        let e = self.latest.clone().unwrap_or_default();
        let has = self.latest.is_some();
        let v = |x: f64, dec: usize| {
            if has {
                format!("{x:.dec$}")
            } else {
                "--".into()
            }
        };

        ui.columns(5, |cols| {
            vital_card(
                &mut cols[0],
                "HEART RATE",
                &v(e.raw.heart_rate_bpm, 0),
                "bpm",
                &format!("avg {:.1}", e.avg.heart_rate_bpm),
                e.trend_per_min.heart_rate_bpm,
                e.status.heart_rate_bpm,
                stale || !has,
            );
            vital_card(
                &mut cols[1],
                "SpO2",
                &v(e.raw.spo2_pct, 1),
                "%",
                &format!("avg {:.1}", e.avg.spo2_pct),
                e.trend_per_min.spo2_pct,
                e.status.spo2_pct,
                stale || !has,
            );
            vital_card(
                &mut cols[2],
                "CORE TEMP",
                &v(e.raw.core_temp_c, 2),
                "°C",
                &format!("avg {:.2}", e.avg.core_temp_c),
                e.trend_per_min.core_temp_c,
                e.status.core_temp_c,
                stale || !has,
            );
            let bp = if has {
                format!(
                    "{:.0}/{:.0}",
                    e.raw.bp_systolic_mmhg, e.raw.bp_diastolic_mmhg
                )
            } else {
                "--/--".into()
            };
            vital_card(
                &mut cols[3],
                "BLOOD PRESSURE",
                &bp,
                "mmHg",
                &format!(
                    "avg {:.0}/{:.0}",
                    e.avg.bp_systolic_mmhg, e.avg.bp_diastolic_mmhg
                ),
                e.trend_per_min.bp_systolic_mmhg,
                e.status.bp_systolic_mmhg.max(e.status.bp_diastolic_mmhg),
                stale || !has,
            );
            vital_card(
                &mut cols[4],
                "CABIN RADIATION",
                &v(e.raw.radiation_usv_h, 1),
                "µSv/h",
                &format!("dose {:.2} µSv", e.cumulative_dose_usv),
                e.trend_per_min.radiation_usv_h,
                e.status.radiation_usv_h,
                stale || !has,
            );
        });
    }

    fn charts(&self, ui: &mut egui::Ui) {
        let s = &self.series;
        ui.columns(2, |cols| {
            vital_plot(
                &mut cols[0],
                "plot_hr",
                "Heart rate (bpm)",
                &[("HR", &s.hr, C_CRITICAL), ("HR avg", &s.hr_avg, C_ACCENT)],
                &[(50.0, C_WARNING), (100.0, C_WARNING), (130.0, C_CRITICAL)],
                (40.0, 140.0),
            );
            vital_plot(
                &mut cols[1],
                "plot_spo2",
                "SpO2 (%)",
                &[("SpO2", &s.spo2, C_ACCENT)],
                &[(94.0, C_WARNING), (90.0, C_CRITICAL)],
                (85.0, 100.0),
            );
            vital_plot(
                &mut cols[0],
                "plot_temp",
                "Core body temperature (°C)",
                &[("Temp", &s.temp, Color32::from_rgb(230, 126, 34))],
                &[(36.0, C_WARNING), (38.0, C_WARNING), (39.5, C_CRITICAL)],
                (35.5, 39.0),
            );
            vital_plot(
                &mut cols[1],
                "plot_bp",
                "Blood pressure (mmHg)",
                &[
                    ("Systolic", &s.sys, Color32::from_rgb(155, 89, 182)),
                    ("Diastolic", &s.dia, Color32::from_rgb(26, 188, 156)),
                ],
                &[(140.0, C_WARNING), (90.0, C_WARNING), (180.0, C_CRITICAL)],
                (50.0, 190.0),
            );
        });
        vital_plot(
            ui,
            "plot_rad",
            "Cabin radiation dose-rate (µSv/h)",
            &[("Dose-rate", &s.rad, C_WARNING)],
            &[(50.0, C_WARNING), (200.0, C_CRITICAL)],
            (0.0, 60.0),
        );
    }

    fn risk_view(&self, ui: &mut egui::Ui) {
        let Some(e) = &self.latest else {
            ui.label(RichText::new("Awaiting telemetry…").color(C_STALE));
            return;
        };
        if e.features.is_empty() {
            ui.label(
                RichText::new(
                    "No extended telemetry: the simulator is an older build, or the \
                     analysis engine could not load ext_analysis.py (see System log).",
                )
                .color(C_WARNING),
            );
            return;
        }
        let dim = self.is_stale();

        // Composite banner.
        let comp = e.metric("composite_risk");
        let ccol = if dim { C_STALE } else { risk_color(comp) };
        Frame::none()
            .fill(ccol.gamma_multiply(0.2))
            .stroke(Stroke::new(1.5, ccol))
            .rounding(6.0)
            .inner_margin(Margin::symmetric(12.0, 6.0))
            .show(ui, |ui| {
                ui.set_min_width(ui.available_width());
                ui.horizontal_wrapped(|ui| {
                    ui.label(
                        RichText::new(format!("MISSION RISK {comp:.0}/100"))
                            .strong()
                            .size(18.0)
                            .color(ccol),
                    );
                    ui.separator();
                    ui.label(format!(
                        "mission day {:.1} · dose {:.2} mSv ({:.1}% of limit) · est. lifetime cancer risk +{:.3}% · bone {:+.2}% · lean mass {:+.1}%",
                        e.metric("mission_day"),
                        e.metric("cumulative_dose_msv"),
                        e.metric("career_limit_pct"),
                        e.metric("cancer_risk_pct"),
                        e.metric("bmd_change_pct"),
                        e.metric("lean_change_pct"),
                    ));
                });
            });
        ui.add_space(6.0);

        // One section per hazard group.
        for h in &e.hazards {
            Self::hazard_header(ui, h, dim);
            ui.horizontal_wrapped(|ui| {
                for f in e.features.iter().filter(|f| f.group == h.id) {
                    feature_card(ui, f, dim);
                }
            });
            ui.add_space(8.0);
        }

        ui.separator();
        ui.label(RichText::new("Long-term trends (x = mission day)").heading());
        ui.columns(2, |c| {
            self.ext_plot(
                &mut c[0],
                "x_lym",
                "Lymphocytes (cells/µL)",
                "lymphocytes_per_ul",
                Color32::from_rgb(52, 152, 219),
                &[(1500.0, C_WARNING), (1000.0, C_CRITICAL)],
                (900.0, 2400.0),
            );
            self.ext_plot(
                &mut c[1],
                "x_hrv",
                "HRV – RMSSD (ms)",
                "hrv_rmssd_ms",
                Color32::from_rgb(155, 89, 182),
                &[],
                (10.0, 70.0),
            );
            self.ext_plot(
                &mut c[0],
                "x_rt",
                "Reaction time (ms)",
                "reaction_time_ms",
                Color32::from_rgb(230, 126, 34),
                &[(288.0, C_WARNING), (325.0, C_CRITICAL)],
                (220.0, 340.0),
            );
            self.ext_plot(
                &mut c[1],
                "x_co2",
                "Cabin CO₂ (mmHg)",
                "cabin_co2_mmhg",
                Color32::from_rgb(26, 188, 156),
                &[(4.0, C_WARNING), (6.0, C_CRITICAL)],
                (1.5, 7.5),
            );
            self.ext_plot(
                &mut c[0],
                "x_lean",
                "Lean mass (kg)",
                "lean_mass_kg",
                Color32::from_rgb(241, 196, 15),
                &[],
                (50.0, 59.0),
            );
            self.ext_plot(
                &mut c[1],
                "x_fluid",
                "Fluid index (relative)",
                "fluid_index",
                Color32::from_rgb(52, 152, 219),
                &[],
                (1.0, 1.2),
            );
            self.ext_plot(
                &mut c[0],
                "x_vitd",
                "Vitamin D (ng/mL)",
                "vitamin_d_ngml",
                Color32::from_rgb(243, 156, 18),
                &[(30.0, C_WARNING), (20.0, C_CRITICAL)],
                (10.0, 45.0),
            );
            self.ext_plot(
                &mut c[1],
                "x_work",
                "Workload index (0-100)",
                "workload_index",
                Color32::from_rgb(231, 76, 60),
                &[(75.0, C_WARNING), (90.0, C_CRITICAL)],
                (20.0, 100.0),
            );
        });
    }

    fn hazard_header(ui: &mut egui::Ui, h: &Hazard, dim: bool) {
        let col = if dim { C_STALE } else { level_color(h.level) };
        ui.horizontal(|ui| {
            ui.label(RichText::new(&h.name).heading());
            pill(
                ui,
                &format!("{} · risk {:.0}", h.level.as_str(), h.score),
                col,
            );
        });
    }

    #[allow(clippy::too_many_arguments)]
    fn ext_plot(
        &self,
        ui: &mut egui::Ui,
        id: &str,
        title: &str,
        key: &'static str,
        color: Color32,
        thresholds: &[(f64, Color32)],
        include_y: (f64, f64),
    ) {
        ui.label(RichText::new(title).strong());
        Plot::new(id.to_string())
            .height(150.0)
            .allow_drag(false)
            .allow_zoom(false)
            .allow_scroll(false)
            .allow_boxed_zoom(false)
            .include_y(include_y.0)
            .include_y(include_y.1)
            .x_axis_label("mission day")
            .show(ui, |pui| {
                for (y, c) in thresholds {
                    pui.hline(
                        HLine::new(*y)
                            .color(c.gamma_multiply(0.7))
                            .style(LineStyle::dashed_loose()),
                    );
                }
                if let Some(d) = self.ext_series.get(key) {
                    let pts: Vec<[f64; 2]> = d.iter().copied().collect();
                    pui.line(
                        Line::new(PlotPoints::from(pts))
                            .name(title)
                            .color(color)
                            .width(2.0),
                    );
                }
            });
        ui.add_space(6.0);
    }

    fn alerts_panel(&self, ui: &mut egui::Ui) {
        ui.heading("Active alerts");
        match &self.latest {
            Some(e) if !e.alerts.is_empty() => {
                let mut alerts = e.alerts.clone();
                alerts.sort_by(|a, b| b.level.cmp(&a.level));
                for a in alerts {
                    let col = level_color(a.level);
                    Frame::none()
                        .fill(col.gamma_multiply(0.18))
                        .stroke(Stroke::new(1.0, col))
                        .rounding(4.0)
                        .inner_margin(Margin::same(6.0))
                        .show(ui, |ui| {
                            ui.set_min_width(ui.available_width());
                            ui.label(
                                RichText::new(format!("{} · {}", a.level.as_str(), a.code))
                                    .strong()
                                    .color(col),
                            );
                            ui.label(RichText::new(&a.message).small());
                        });
                    ui.add_space(4.0);
                }
            }
            Some(_) => {
                ui.label(RichText::new("None — all vitals within limits").color(C_NOMINAL));
            }
            None => {
                ui.label(RichText::new("No data yet").color(C_STALE));
            }
        }

        ui.add_space(8.0);
        ui.heading("Analysis");
        if let Some(e) = &self.latest {
            egui::Grid::new("analysis_grid")
                .num_columns(2)
                .spacing([12.0, 4.0])
                .show(ui, |ui| {
                    ui.label("Anomaly score (max |z|)");
                    let col = if e.anomaly_score >= 4.5 {
                        C_WARNING
                    } else {
                        Color32::LIGHT_GRAY
                    };
                    ui.label(RichText::new(format!("{:.2}", e.anomaly_score)).color(col));
                    ui.end_row();
                    ui.label("Session dose");
                    ui.label(format!("{:.3} µSv", e.cumulative_dose_usv));
                    ui.end_row();
                    ui.label("Projected daily dose");
                    ui.label(format!("{:.3} mSv/day", e.projected_daily_dose_msv));
                    ui.end_row();
                    ui.label("Rolling window");
                    ui.label(format!("{} samples", e.window));
                    ui.end_row();
                    ui.label("Python processing");
                    ui.label(format!("{:.0} µs/sample", e.processing_us));
                    ui.end_row();
                    ui.label("Sequence #");
                    ui.label(e.seq.to_string());
                    ui.end_row();
                });
        }

        ui.add_space(8.0);
        ui.heading("Alert event log");
        ScrollArea::vertical()
            .id_salt("alert_log")
            .auto_shrink([false, false])
            .show(ui, |ui| {
                if self.alert_log.is_empty() {
                    ui.label(RichText::new("No events yet").color(C_STALE));
                }
                for entry in &self.alert_log {
                    ui.horizontal_wrapped(|ui| {
                        ui.label(RichText::new(&entry.time).monospace().color(Color32::GRAY));
                        ui.label(RichText::new(&entry.text).color(level_color(entry.level)));
                    });
                }
            });
    }

    fn system_log_panel(&self, ui: &mut egui::Ui) {
        ui.label(RichText::new("System log").strong());
        ScrollArea::vertical()
            .id_salt("system_log")
            .stick_to_bottom(true)
            .auto_shrink([false, false])
            .show(ui, |ui| {
                for line in &self.system_log {
                    ui.label(RichText::new(line).monospace().size(11.0));
                }
            });
    }
}

impl eframe::App for GroundControlApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.drain_events();

        egui::TopBottomPanel::top("top_bar").show(ctx, |ui| {
            ui.add_space(4.0);
            self.top_bar(ui);
            ui.add_space(4.0);
        });

        egui::TopBottomPanel::bottom("system_log")
            .resizable(true)
            .default_height(110.0)
            .show(ctx, |ui| self.system_log_panel(ui));

        egui::SidePanel::right("alerts")
            .resizable(true)
            .default_width(340.0)
            .show(ctx, |ui| self.alerts_panel(ui));

        egui::CentralPanel::default().show(ctx, |ui| {
            self.status_banner(ui);
            ui.add_space(6.0);
            let raised = self.latest.as_ref().map_or(0, |e| {
                e.features
                    .iter()
                    .filter(|f| f.level != Level::Nominal)
                    .count()
            });
            ui.horizontal(|ui| {
                ui.selectable_value(&mut self.tab, Tab::Vitals, "Live vitals");
                let label = if raised > 0 {
                    format!("Risk assessment ({raised} raised)")
                } else {
                    "Risk assessment".to_string()
                };
                ui.selectable_value(&mut self.tab, Tab::Risk, label);
            });
            ui.separator();
            match self.tab {
                Tab::Vitals => {
                    self.vital_cards(ui);
                    ui.add_space(8.0);
                    ScrollArea::vertical()
                        .id_salt("charts")
                        .show(ui, |ui| self.charts(ui));
                }
                Tab::Risk => {
                    ScrollArea::vertical()
                        .id_salt("risk")
                        .show(ui, |ui| self.risk_view(ui));
                }
            }
        });

        // Keep "last packet" age and the critical blink ticking.
        ctx.request_repaint_after(Duration::from_millis(250));
    }
}

// ---------------------------------------------------------------------------
// Widgets
// ---------------------------------------------------------------------------

fn pill(ui: &mut egui::Ui, text: &str, col: Color32) -> egui::Response {
    Frame::none()
        .fill(col.gamma_multiply(0.22))
        .stroke(Stroke::new(1.0, col))
        .rounding(10.0)
        .inner_margin(Margin::symmetric(8.0, 2.0))
        .show(ui, |ui| ui.label(RichText::new(text).strong().color(col)))
        .response
}

#[allow(clippy::too_many_arguments)]
fn vital_card(
    ui: &mut egui::Ui,
    title: &str,
    value: &str,
    unit: &str,
    sub: &str,
    trend_per_min: f64,
    level: Level,
    dim: bool,
) {
    let col = if dim { C_STALE } else { level_color(level) };
    Frame::none()
        .fill(C_PANEL)
        .stroke(Stroke::new(2.0, col))
        .rounding(8.0)
        .inner_margin(Margin::same(10.0))
        .show(ui, |ui| {
            ui.set_min_width(ui.available_width());
            ui.horizontal(|ui| {
                ui.label(
                    RichText::new(title)
                        .small()
                        .strong()
                        .color(Color32::LIGHT_GRAY),
                );
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    ui.label(
                        RichText::new(if dim { "NO DATA" } else { level.as_str() })
                            .small()
                            .strong()
                            .color(col),
                    );
                });
            });
            ui.horizontal(|ui| {
                ui.label(RichText::new(value).size(34.0).strong().color(col));
                ui.label(RichText::new(unit).size(14.0).color(Color32::GRAY));
            });
            let trend = if trend_per_min.abs() < 0.05 {
                "steady".to_string()
            } else {
                format!("{trend_per_min:+.1}/min")
            };
            ui.label(
                RichText::new(format!("{sub}  ·  {trend}"))
                    .small()
                    .color(Color32::GRAY),
            );
        });
}

fn feature_card(ui: &mut egui::Ui, f: &Feature, dim: bool) {
    let col = if !f.has_data || dim {
        C_STALE
    } else {
        level_color(f.level)
    };
    Frame::none()
        .fill(C_PANEL)
        .stroke(Stroke::new(1.5, col))
        .rounding(8.0)
        .inner_margin(Margin::same(8.0))
        .show(ui, |ui| {
            ui.set_width(310.0);
            ui.horizontal(|ui| {
                ui.label(
                    RichText::new(&f.name)
                        .small()
                        .strong()
                        .color(Color32::LIGHT_GRAY),
                );
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    let t = if f.has_data {
                        f.level.as_str()
                    } else {
                        "NO DATA"
                    };
                    ui.label(RichText::new(t).small().strong().color(col));
                });
            });
            ui.label(RichText::new(&f.value).size(22.0).strong().color(col));
            ui.add(
                egui::ProgressBar::new((f.risk / 100.0).clamp(0.0, 1.0) as f32)
                    .desired_width(ui.available_width())
                    .fill(if f.has_data {
                        risk_color(f.risk)
                    } else {
                        C_STALE
                    })
                    .text(format!("risk {:.0}", f.risk)),
            );
            ui.label(RichText::new(&f.detail).small().color(Color32::GRAY));
            if f.has_data && f.level != Level::Nominal && !f.action.is_empty() {
                ui.label(
                    RichText::new(format!("Action: {}", f.action))
                        .small()
                        .italics()
                        .color(col),
                );
            }
        });
}

fn vital_plot(
    ui: &mut egui::Ui,
    id: &str,
    title: &str,
    series: &[(&str, &VecDeque<[f64; 2]>, Color32)],
    thresholds: &[(f64, Color32)],
    include_y: (f64, f64),
) {
    ui.label(RichText::new(title).strong());
    Plot::new(id)
        .height(170.0)
        .legend(Legend::default())
        .allow_drag(false)
        .allow_zoom(false)
        .allow_scroll(false)
        .allow_boxed_zoom(false)
        .include_y(include_y.0)
        .include_y(include_y.1)
        .x_axis_label("t (s)")
        .show(ui, |pui| {
            for (y, c) in thresholds {
                pui.hline(
                    HLine::new(*y)
                        .color(c.gamma_multiply(0.7))
                        .style(LineStyle::dashed_loose()),
                );
            }
            for (name, data, color) in series {
                let pts: Vec<[f64; 2]> = data.iter().copied().collect();
                pui.line(
                    Line::new(PlotPoints::from(pts))
                        .name(*name)
                        .color(*color)
                        .width(2.0),
                );
            }
        });
    ui.add_space(6.0);
}

fn pretty_vital(v: &str) -> &str {
    match v {
        "heart_rate_bpm" => "heart rate",
        "spo2_pct" => "SpO2",
        "core_temp_c" => "core temp",
        "bp_systolic_mmhg" => "systolic BP",
        "bp_diastolic_mmhg" => "diastolic BP",
        "radiation_usv_h" => "radiation",
        other => other,
    }
}

fn describe_link(s: &LinkState) -> String {
    match s {
        LinkState::Idle => "idle".into(),
        LinkState::Scanning => "scanning for bio-chip…".into(),
        LinkState::Connecting(p) => format!("connecting to {p}…"),
        LinkState::Connected { peer, transport } => format!("connected to {peer} via {transport}"),
        LinkState::Disconnected(r) => r.clone(),
        LinkState::Error(e) => e.clone(),
    }
}
