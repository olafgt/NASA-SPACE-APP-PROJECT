#!/usr/bin/env python3
"""
Ground Control - Telemetry Analysis Engine
==========================================

Spawned by the Rust Ground Control app as a child process. Pure standard
library (Python 3.8+), no pip installs required.

Protocol (JSON Lines over stdio)
--------------------------------
stdin  <- one object per line, either a raw sample:
            {"seq": 12, "heart_rate_bpm": 72.3, "spo2_pct": 98.1,
             "core_temp_c": 36.92, "bp_systolic_mmhg": 118, "bp_diastolic_mmhg": 76,
             "radiation_usv_h": 18.4, "received_at_ms": 1731600000000}
          or a control command:
            {"cmd": "reset"}

stdout -> one object per line:
            {"type": "ready", ...}            once at start-up
            {"type": "telemetry", ...}        one per raw sample (enriched)
            {"type": "reset"}                 acknowledgement of a reset
stderr -> human-readable diagnostics (shown in the dashboard's system log)

Analysis performed per sample
-----------------------------
* Rolling window statistics (mean, std, linear trend per minute) per vital.
* Clinical / operational threshold classification -> NOMINAL / WARNING / CRITICAL
  (tachycardia, bradycardia, hypoxia, fever, hypothermia, hyper/hypotension,
  radiation exposure).
* Persistence filter: WARNING-level breaches must persist for N consecutive
  samples before they alarm (suppresses motion artefacts); CRITICAL breaches
  alarm immediately.
* Statistical anomaly detection: z-score of each new sample against the rolling
  window -> RAPID_CHANGE alerts and an overall anomaly score.
* Radiation dosimetry: cumulative session dose (uSv) and projected daily dose (mSv).

Run `python analysis.py --selftest` to verify the engine without Rust.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from collections import deque

# Always find ext_analysis.py next to this file, however the script is launched.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:  # extended hazard analysis lives next to this file
    from ext_analysis import ExtendedAnalyzer
except ImportError as _e:  # pragma: no cover
    ExtendedAnalyzer = None
    _EXT_IMPORT_ERROR = str(_e)

ENGINE_VERSION = "2.0.0"

NOMINAL, WARNING, CRITICAL = "NOMINAL", "WARNING", "CRITICAL"
RANK = {NOMINAL: 0, WARNING: 1, CRITICAL: 2}

VITALS = (
    "heart_rate_bpm",
    "spo2_pct",
    "core_temp_c",
    "bp_systolic_mmhg",
    "bp_diastolic_mmhg",
    "radiation_usv_h",
)

LABELS = {
    "heart_rate_bpm": ("Heart rate", "bpm", 1),
    "spo2_pct": ("SpO2", "%", 1),
    "core_temp_c": ("Core temp", "C", 2),
    "bp_systolic_mmhg": ("Systolic BP", "mmHg", 0),
    "bp_diastolic_mmhg": ("Diastolic BP", "mmHg", 0),
    "radiation_usv_h": ("Radiation dose-rate", "uSv/h", 1),
}

# Threshold table. None = no limit on that side.
# Physiological limits follow common adult early-warning conventions;
# radiation limits are illustrative ops limits (ISS nominal ~ 15-25 uSv/h).
LIMITS = {
    "heart_rate_bpm": dict(crit_low=40, warn_low=50, warn_high=100, crit_high=130,
                           low_code="BRADYCARDIA", high_code="TACHYCARDIA"),
    "spo2_pct": dict(crit_low=90, warn_low=94, warn_high=None, crit_high=None,
                     low_code="HYPOXIA", high_code=None),
    "core_temp_c": dict(crit_low=35.0, warn_low=36.0, warn_high=38.0, crit_high=39.5,
                        low_code="HYPOTHERMIA", high_code="HYPERTHERMIA"),
    "bp_systolic_mmhg": dict(crit_low=80, warn_low=90, warn_high=140, crit_high=180,
                             low_code="HYPOTENSION", high_code="HYPERTENSION"),
    "bp_diastolic_mmhg": dict(crit_low=None, warn_low=50, warn_high=90, crit_high=120,
                              low_code="HYPOTENSION", high_code="HYPERTENSION"),
    "radiation_usv_h": dict(crit_low=None, warn_low=None, warn_high=50, crit_high=200,
                            low_code=None, high_code="RADIATION_EXPOSURE"),
}

# Minimum standard deviation per vital used for z-scores, so that a very quiet
# window doesn't turn ordinary sensor noise into "anomalies".
MIN_STD = {
    "heart_rate_bpm": 2.0,
    "spo2_pct": 0.5,
    "core_temp_c": 0.08,
    "bp_systolic_mmhg": 3.0,
    "bp_diastolic_mmhg": 3.0,
    "radiation_usv_h": 2.0,
}


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def emit(obj: dict) -> None:
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def classify(name: str, v: float):
    """Return (level, code, limit_text) for a single value."""
    lim = LIMITS[name]
    if lim["crit_low"] is not None and v < lim["crit_low"]:
        return CRITICAL, lim["low_code"], f"< {lim['crit_low']}"
    if lim["crit_high"] is not None and v > lim["crit_high"]:
        return CRITICAL, lim["high_code"], f"> {lim['crit_high']}"
    if lim["warn_low"] is not None and v < lim["warn_low"]:
        return WARNING, lim["low_code"], f"< {lim['warn_low']}"
    if lim["warn_high"] is not None and v > lim["warn_high"]:
        return WARNING, lim["high_code"], f"> {lim['warn_high']}"
    return NOMINAL, None, None


class VitalTracker:
    """Rolling window + persistence state for one vital sign."""

    def __init__(self, window: int):
        self.values: deque = deque(maxlen=window)
        self.times: deque = deque(maxlen=window)
        self.streak = 0  # consecutive non-nominal samples

    def mean_std(self):
        n = len(self.values)
        if n == 0:
            return None, None
        m = sum(self.values) / n
        if n < 2:
            return m, 0.0
        var = sum((x - m) ** 2 for x in self.values) / (n - 1)
        return m, math.sqrt(var)

    def trend_per_min(self) -> float:
        """Least-squares slope of value vs. time, in units per minute."""
        n = len(self.values)
        if n < 5:
            return 0.0
        t0 = self.times[0]
        xs = [(t - t0) / 1000.0 for t in self.times]
        ys = list(self.values)
        mx, my = sum(xs) / n, sum(ys) / n
        sxx = sum((x - mx) ** 2 for x in xs)
        if sxx <= 1e-9:
            return 0.0
        sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
        return sxy / sxx * 60.0


class AnalysisEngine:
    def __init__(self, window: int = 30, persistence: int = 2, z_threshold: float = 4.5,
                 min_samples_for_z: int = 10, career_limit_msv: float = 600.0):
        self.window = max(5, window)
        self.persistence = max(1, persistence)
        self.z_threshold = z_threshold
        self.min_samples_for_z = min_samples_for_z
        self.ext = ExtendedAnalyzer(self.persistence, career_limit_msv) if ExtendedAnalyzer else None
        self.reset()

    def reset(self) -> None:
        if getattr(self, "ext", None):
            self.ext.reset()
        self.trackers = {v: VitalTracker(self.window) for v in VITALS}
        self.cumulative_dose_usv = 0.0
        self.last_ts_ms = None
        self.last_seq = None
        self.samples = 0

    def process(self, s: dict) -> dict:
        t_start = time.perf_counter()
        seq_now = int(s.get("seq", 0))
        if self.last_seq is not None and seq_now < self.last_seq:
            log(f"sequence went backwards ({self.last_seq} -> {seq_now}): simulator restarted, resetting analysis")
            self.reset()
        self.last_seq = seq_now
        ts = int(s.get("received_at_ms") or time.time() * 1000)

        # --- radiation dosimetry (integrate dose-rate over elapsed *mission* time) ---
        ext = s.get("ext") or {}
        mask = int(ext.get("groups_mask", 0) or 0)
        scale = float(ext.get("time_scale") or 1.0) if mask & 1 else 1.0
        dt_s = 1.0 if self.last_ts_ms is None else (ts - self.last_ts_ms) / 1000.0
        dt_s = min(max(dt_s, 0.0), 5.0)  # clamp gaps / clock jumps (real seconds)
        self.last_ts_ms = ts
        rad = float(s["radiation_usv_h"])
        self.cumulative_dose_usv += rad * dt_s * max(scale, 0.0) / 3600.0

        raw, avg, trend, zs, status = {}, {}, {}, {}, {}
        alerts = []
        overall = NOMINAL
        anomaly_score = 0.0

        for name in VITALS:
            v = float(s[name])
            tr = self.trackers[name]
            label, unit, dec = LABELS[name]

            # z-score of the new value against the window *before* it.
            mean, std = tr.mean_std()
            z = 0.0
            if mean is not None and len(tr.values) >= self.min_samples_for_z:
                z = (v - mean) / max(std, MIN_STD[name])
            tr.values.append(v)
            tr.times.append(ts)

            m, _ = tr.mean_std()
            raw[name] = v
            avg[name] = round(m, 3)
            trend[name] = round(tr.trend_per_min(), 3)
            zs[name] = round(z, 2)
            anomaly_score = max(anomaly_score, abs(z))

            # --- threshold classification with persistence filter ----------
            level, code, limit_text = classify(name, v)
            if level == NOMINAL:
                tr.streak = 0
                confirmed = NOMINAL
            else:
                tr.streak += 1
                confirmed = level if (level == CRITICAL or tr.streak >= self.persistence) else NOMINAL

            status[name] = confirmed
            if confirmed != NOMINAL:
                pretty = code.replace("_", " ").title()
                if confirmed == CRITICAL:
                    pretty = "Severe " + pretty.lower()
                alerts.append({
                    "vital": name,
                    "level": confirmed,
                    "code": code,
                    "message": f"{pretty}: {label} {v:.{dec}f} {unit} (limit {limit_text}; "
                               f"{len(tr.values)}-sample avg {m:.{dec}f})",
                })
                if RANK[confirmed] > RANK[overall]:
                    overall = confirmed

            # --- statistical anomaly (rapid change / artefact) -------------
            if abs(z) >= self.z_threshold:
                direction = "above" if z > 0 else "below"
                alerts.append({
                    "vital": name,
                    "level": WARNING,
                    "code": "RAPID_CHANGE",
                    "message": f"Rapid change: {label} {v:.{dec}f} {unit} is "
                               f"{abs(v - mean):.{dec}f} {unit} {direction} rolling mean (z={z:+.1f})",
                })
                if RANK[WARNING] > RANK[overall]:
                    overall = WARNING

        self.samples += 1
        win_rad = avg["radiation_usv_h"]

        # --- extended hazards: radiation / isolation / gravity / environment ---
        features, hazards, metrics, ext_out = [], [], {}, {}
        if self.ext is not None and ext:
            res = self.ext.process(ext, ts, {
                "hr": float(s["heart_rate_bpm"]), "sys": float(s["bp_systolic_mmhg"]),
                "temp": float(s["core_temp_c"]), "rad": rad,
                "spo2": float(s["spo2_pct"]), "dose_msv": self.cumulative_dose_usv / 1000.0})
            features, hazards, metrics, ext_out = res["features"], res["hazards"], res["metrics"], ext
            alerts.extend(res["alerts"])
            if RANK[res["overall"]] > RANK[overall]:
                overall = res["overall"]

        return {
            "type": "telemetry",
            "seq": int(s.get("seq", 0)),
            "received_at_ms": ts,
            "raw": raw,
            "avg": avg,
            "trend_per_min": trend,
            "zscore": zs,
            "status": status,
            "overall": overall,
            "alerts": alerts,
            "cumulative_dose_usv": round(self.cumulative_dose_usv, 4),
            "projected_daily_dose_msv": round(win_rad * 24.0 / 1000.0, 4),
            "anomaly_score": round(anomaly_score, 2),
            "window": len(self.trackers["heart_rate_bpm"].values),
            "ext": ext_out,
            "features": features,
            "hazards": hazards,
            "metrics": metrics,
            "processing_us": round((time.perf_counter() - t_start) * 1e6, 1),
        }


# --------------------------------------------------------------------------
# stdio service loop
# --------------------------------------------------------------------------
def serve(engine: AnalysisEngine) -> int:
    emit({"type": "ready", "engine": "analysis.py", "version": ENGINE_VERSION,
          "python": sys.version.split()[0], "window": engine.window,
          "persistence": engine.persistence, "z_threshold": engine.z_threshold,
          "extended": engine.ext is not None})
    if engine.ext is None:
        log(f"WARNING: ext_analysis.py not importable ({_EXT_IMPORT_ERROR}); extended hazards disabled")
    log(f"analysis engine {ENGINE_VERSION} ready (window={engine.window}, "
        f"persistence={engine.persistence}, z>={engine.z_threshold})")

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError as e:
            log(f"bad JSON from host: {e}: {line[:120]}")
            continue
        try:
            if msg.get("cmd") == "reset":
                engine.reset()
                emit({"type": "reset"})
                log("engine state reset by host")
                continue
            emit(engine.process(msg))
        except KeyError as e:
            log(f"sample missing field {e}: {line[:120]}")
        except Exception as e:  # never die on one bad sample
            log(f"analysis error: {type(e).__name__}: {e}")
    log("stdin closed - analysis engine exiting")
    return 0


# --------------------------------------------------------------------------
# self test (no Rust needed)
# --------------------------------------------------------------------------
def selftest() -> int:
    import random

    rnd = random.Random(7)
    eng = AnalysisEngine()
    base = dict(heart_rate_bpm=72, spo2_pct=98.2, core_temp_c=36.95,
                bp_systolic_mmhg=118, bp_diastolic_mmhg=76, radiation_usv_h=18)
    ts = 1_700_000_000_000
    seen = {}

    def run(n, override=None, label=""):
        nonlocal ts
        for _ in range(n):
            s = {k: v + rnd.gauss(0, 0.6 if k != "core_temp_c" else 0.02) for k, v in base.items()}
            if override:
                s.update(override)
            ts += 1000
            s["seq"] = eng.samples
            s["received_at_ms"] = ts
            out = eng.process(s)
            for a in out["alerts"]:
                seen.setdefault((a["code"], a["level"]), a["message"])
        print(f"  {label:<38} overall={out['overall']:<8} anomaly={out['anomaly_score']:<6} "
              f"alerts={[a['code'] for a in out['alerts']]}")

    print("analysis.py self-test")
    run(30, label="30 s nominal")
    run(1, {"heart_rate_bpm": 112}, label="1-sample glitch (HR 112)")
    run(5, label="back to nominal")
    run(5, {"heart_rate_bpm": 142}, label="sustained tachycardia (HR 142)")
    run(5, {"spo2_pct": 86.0}, label="hypoxia (SpO2 86)")
    run(5, {"radiation_usv_h": 380.0}, label="solar particle event (380 uSv/h)")
    run(5, {"core_temp_c": 38.6}, label="fever (38.6 C)")
    run(5, {"bp_systolic_mmhg": 184, "bp_diastolic_mmhg": 121}, label="hypertensive crisis")

    expected = [("TACHYCARDIA", CRITICAL), ("HYPOXIA", CRITICAL), ("RADIATION_EXPOSURE", CRITICAL),
                ("HYPERTHERMIA", WARNING), ("HYPERTENSION", CRITICAL), ("RAPID_CHANGE", WARNING)]
    missing = [e for e in expected if e not in seen]
    # The single glitch must NOT have produced a tachycardia WARNING on its own.
    print("\nFirst message per alert type:")
    for (code, lvl), msg in seen.items():
        print(f"  [{lvl:<8}] {msg}")
    print(f"\ncumulative dose: {eng.cumulative_dose_usv:.3f} uSv over {eng.samples} samples")
    if missing:
        print(f"SELFTEST FAILED - missing alerts: {missing}")
        return 1
    print("SELFTEST PASSED")
    return 0


def selftest_ext() -> int:
    """One scenario per extended feature: each must raise its expected alert; nominal must stay silent."""
    core = dict(heart_rate_bpm=72, spo2_pct=98.0, core_temp_c=36.95, bp_systolic_mmhg=118,
                bp_diastolic_mmhg=76, radiation_usv_h=18.0)
    nominal = dict(groups_mask=63, hrv_rmssd_ms=45, resp_rate_bpm=14, cabin_co2_mmhg=2.2, cabin_o2_pct=20.9,
                   pm25_ugm3=8, time_scale=3600, lymphocytes_per_ul=2200, arterial_pwv_ms=7.0,
                   reaction_time_ms=250, reaction_error_pct=2.0, microbial_cfu_m3=120, cortisol_ugdl=12,
                   sleep_hours=7.2, sleep_efficiency_pct=90, mood_score=78, bone_ntx=30, lean_mass_kg=58,
                   fluid_index=1.14, crp_mgl=1.0, leg_strength_pct=100, orthostatic_hr_rise=12,
                   exercise_min=120, mission_day=1.0, humidity_pct=45,
                   vitamin_d_ngml=34, calcium_intake_mg=1000, energy_intake_kcal=2700, mech_load_pct=100,
                   workload_index=55, work_hours=8.5, social_contact_min=150, earth_comm_min=45,
                   selfcheck_pct=95, report_delay_h=1.5, peer_check_pct=92, sodium_intake_mg=3200)

    def run(override, ticks=40, lead=80, career=600.0, base_core=None):
        eng = AnalysisEngine(career_limit_msv=career)
        ts, hits, out = 1_700_000_000_000, set(), None
        for i in range(lead + ticks):
            ext = dict(nominal)
            # a healthy fluid index follows the expected adaptation curve as the mission clock advances
            ext["fluid_index"] = round(1.04 + 0.10 * math.exp(-(i / 24.0) / 4.0), 3)
            if i >= lead:
                ext.update(override)
            ext["mission_day"] = round(1.0 + i / 24.0, 1)       # 1 tick = 1 mission hour
            ts += 1000
            sample = dict(core, **(base_core or {}), seq=i, received_at_ms=ts, ext=ext)
            out = eng.process(sample)
            if i >= lead:
                hits |= {(a["code"], a["level"]) for a in out["alerts"]}
        return hits, out

    print("\nextended hazards self-test (19 features)")
    ok = True
    quiet, qo = run({}, ticks=60)   # 140 ticks = 5.8 mission days
    status = "ok" if not quiet else "FAIL"
    ok &= not quiet
    print(f"  {'nominal 140 ticks':<34} alerts={sorted(quiet)}  [{status}]")

    cases = [
        ("rad_immune: lymphocytes 1300", {"lymphocytes_per_ul": 1300}, "IMMUNE_SUPPRESSION", CRITICAL, 40, {}),
        ("rad_cardio: HRV suppressed", {"hrv_rmssd_ms": 20}, "HRV_SUPPRESSION", CRITICAL, 130, {}),
        ("rad_cardio: arterial stiffening", {"arterial_pwv_ms": 9.2}, "ARTERIAL_STIFFENING", CRITICAL, 70, {}),
        ("rad_cns: reaction time 340 ms", {"reaction_time_ms": 340}, "CNS_SLOWING", CRITICAL, 30, {}),
        ("iso_sleep: 4 h, 70 % eff", {"sleep_hours": 4.0, "sleep_efficiency_pct": 70}, "SHORT_SLEEP", CRITICAL, 30, {}),
        ("iso_mood: score 40", {"mood_score": 40}, "MOOD_DECLINE", CRITICAL, 30, {}),
        ("grav_bone: NTx 46", {"bone_ntx": 46}, "BONE_LOSS_RATE", CRITICAL, 30, {}),
        ("grav_muscle: exercise skipped", {"exercise_min": 5}, "COUNTERMEASURE_SKIPPED", CRITICAL, 30, {}),
        ("grav_muscle: strength 70 %", {"leg_strength_pct": 70}, "STRENGTH_LOSS", CRITICAL, 30, {}),
        ("grav_fluid: index 1.30", {"fluid_index": 1.30}, "FLUID_SHIFT", CRITICAL, 30, {}),
        ("grav_cv: stand-test +32 bpm", {"orthostatic_hr_rise": 32}, "ORTHOSTATIC_INTOLERANCE", CRITICAL, 30, {}),
        ("env_immune: cortisol/CRP/lymph", {"lymphocytes_per_ul": 1500, "cortisol_ugdl": 24, "crp_mgl": 14}, "IMMUNE_DEPRESSION", CRITICAL, 40, {}),
        ("env_resp: CO2 6.5 mmHg", {"cabin_co2_mmhg": 6.5}, "HIGH_CO2", CRITICAL, 30, {}),
        ("env_resp: O2 17.5 %", {"cabin_o2_pct": 17.5}, "LOW_O2", CRITICAL, 30, {}),
        ("env_infection: microbes 1600", {"microbial_cfu_m3": 1600}, "MICROBIAL_LOAD", CRITICAL, 30, {}),
        ("grav_loading: loading 20 % of Rx", {"mech_load_pct": 20}, "LOADING_DEFICIT", CRITICAL, 30, {}),
        ("grav_nutrition: calcium 450 mg", {"calcium_intake_mg": 450}, "CALCIUM_LOW", CRITICAL, 30, {}),
        ("grav_nutrition: energy 1500 kcal", {"energy_intake_kcal": 1500}, "ENERGY_DEFICIT", CRITICAL, 30, {}),
        ("grav_nutrition: vitamin D 17", {"vitamin_d_ngml": 17}, "VITAMIN_D_LOW", CRITICAL, 30, {}),
        ("grav_nutrition: sodium 5200 mg", {"sodium_intake_mg": 5200}, "SODIUM_HIGH", CRITICAL, 30, {}),
        ("iso_workload: index 95, 14.5 h", {"workload_index": 95, "work_hours": 14.5}, "WORKLOAD_HIGH", CRITICAL, 30, {}),
        ("iso_confinement: social 30, comms 0", {"social_contact_min": 30, "earth_comm_min": 0}, "SOCIAL_ISOLATION", CRITICAL, 30, {}),
        ("iso_confinement: Earth comms 12 min", {"earth_comm_min": 12}, "EARTH_COMMS_LOW", WARNING, 30, {}),
        ("iso_reporting: self-check 40 %", {"selfcheck_pct": 40}, "SELF_MONITORING_LAPSE", CRITICAL, 30, {}),
        ("iso_reporting: report delay 19 h", {"report_delay_h": 19}, "REPORT_DELAY", CRITICAL, 30, {}),
        ("iso_reporting: peer checks 50 %", {"peer_check_pct": 50}, "PEER_CHECK_LAPSE", CRITICAL, 30, {}),
    ]
    for label, ov, code, lvl, ticks, _ in cases:
        hits, _o = run(ov, ticks=ticks)
        good = (code, lvl) in hits
        ok &= good
        print(f"  {label:<34} -> {code:<24} {lvl:<8} [{'ok' if good else 'FAIL'}]")

    # rad_cancer: dose accumulates in MISSION time (1 tick = 1 mission hour at 18 uSv/h)
    hits, o = run({}, ticks=20, lead=80, career=2.0)
    dose = o["metrics"]["cumulative_dose_msv"]
    good = ("DOSE_LIMIT", CRITICAL) in hits and abs(dose - 1.8) < 0.1
    ok &= good
    print(f"  {'rad_cancer: 100 h @18 uSv/h':<34} -> DOSE_LIMIT {CRITICAL:<8} dose={dose:.2f} mSv [{'ok' if good else 'FAIL'}]")

    # env_infection composite from a fever + immune + CRP (no microbes alone)
    hits, o = run({"crp_mgl": 20, "lymphocytes_per_ul": 1700, "microbial_cfu_m3": 700}, ticks=40,
                  base_core={"core_temp_c": 38.9})
    good = any(c == "INFECTION_RISK" for c, _ in hits)
    ok &= good
    print(f"  {'env_infection: composite score':<34} -> INFECTION_RISK{'':9} score={o['metrics'].get('infection_score')} [{'ok' if good else 'FAIL'}]")
    print("EXTENDED SELFTEST " + ("PASSED" if ok else "FAILED"))
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(description="Ground Control telemetry analysis engine (stdio JSONL)")
    p.add_argument("--window", type=int, default=30, help="rolling window size in samples")
    p.add_argument("--persistence", type=int, default=2,
                   help="consecutive samples required before a WARNING alarms")
    p.add_argument("--z-threshold", type=float, default=4.5,
                   help="z-score that flags a RAPID_CHANGE anomaly")
    p.add_argument("--career-limit-msv", type=float, default=600.0,
                   help="career effective-dose limit used by the cancer-risk gauge (mSv)")
    p.add_argument("--selftest", action="store_true", help="run a synthetic scenario and exit")
    a = p.parse_args()
    if a.selftest:
        rc = selftest()
        if ExtendedAnalyzer is not None:
            rc |= selftest_ext()
        return rc
    return serve(AnalysisEngine(window=a.window, persistence=a.persistence,
                                z_threshold=a.z_threshold, career_limit_msv=a.career_limit_msv))


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(0)
