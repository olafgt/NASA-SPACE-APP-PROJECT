"""
Extended hazard analysis (imported by analysis.py)
==================================================

Evaluates the 19 features on the project sheets, grouped into four hazards:

  RADIATION     rad_immune   immune effects (lymphocyte count vs. baseline and dose)
                rad_cardio   cardiovascular (HRV suppression, arterial stiffness)
                rad_cns      central nervous system (reaction time / errors vs. dose-rate)
                rad_cancer   cumulative effective dose -> illustrative cancer-risk estimate
  ISOLATION &   iso_sleep    sleep duration, efficiency, 7-night sleep debt
  BEHAVIORAL    iso_mood     daily mood score vs. personal baseline
                iso_cognition long-horizon reaction-time / error drift
                iso_workload crew workload index and work-day length
                iso_confinement social contact and communication with Earth
                iso_reporting self-monitoring completion, peer checks, symptom-report delay
  GRAVITY       grav_bone    bone-turnover marker -> projected bone-density loss
                grav_muscle  lean-mass loss rate, strength, countermeasure adherence
                grav_fluid   headward fluid shift vs. expected adaptation curve
                grav_cv      cardiovascular deconditioning (orthostatic HR rise)
                grav_loading mechanical loading delivered vs. prescription, exercise adherence
                grav_nutrition calcium / energy / vitamin D / sodium
  ENVIRONMENT   env_immune   composite immune index (lymphocytes, cortisol, CRP)
                env_resp     cabin CO2 / O2 / particulates / humidity + respiratory rate
                env_infection infection-risk score (microbial load, fever, immune, CRP)

Method
------
* Personal baselines: the first N samples of fast signals define the astronaut's own
  normal (Baseline); slow signals use population norms plus the expected-time-course.
* Every feature reduces to a list of "badness" measures with (warn, crit) limits.
  The worst one sets the level and a 0-100 risk score; persistence filtering
  (WARNING must repeat `persistence` samples, CRITICAL is immediate) matches analysis.py.
* Hazard score = worst feature risk; composite = 0.5 * max + 0.5 * mean of hazard scores.

All limits are illustrative operational defaults for a *simulation*, not clinical
guidance. Edit the numbers in the evaluators to match your own standards.
"""

from __future__ import annotations

import math
from collections import deque

NOMINAL, WARNING, CRITICAL = "NOMINAL", "WARNING", "CRITICAL"
RANK = {NOMINAL: 0, WARNING: 1, CRITICAL: 2}

# Bit g of ext["groups_mask"] = group g received (see telemetry-protocol EXT_LAYOUT)
G_FAST, G_IMMUNE, G_DAILY, G_DAILY2, G_NUTR, G_BEHAV = 1, 2, 4, 8, 16, 32

ICRP_CANCER_RISK_PER_SV = 0.055   # nominal detriment-adjusted risk coefficient (LNT), per Sv
SLEEP_NEED_H = 7.5
HOLD_SAMPLES = 5      # an alert stays raised this many samples after its cause drops below the limit

HAZARDS = [
    ("radiation", "Space radiation", ["rad_immune", "rad_cardio", "rad_cns", "rad_cancer"]),
    ("isolation", "Isolation & behavioral health",
     ["iso_sleep", "iso_mood", "iso_cognition", "iso_workload", "iso_confinement", "iso_reporting"]),
    ("gravity", "Altered gravity",
     ["grav_bone", "grav_muscle", "grav_fluid", "grav_cv", "grav_loading", "grav_nutrition"]),
    ("environment", "Hostile closed environment", ["env_immune", "env_resp", "env_infection"]),
]
FEATURE_IDS = [f for _, _, fs in HAZARDS for f in fs]

# Recommended response per feature, taken from the Resolution Plan (shown when a feature is raised).
_A_IMMUNE = "Environmental control, nutrition, sleep, stress management, symptom tracking; isolate ill crew early."
_A_CV = "Aerobic + resistive exercise, regular vital-sign checks, fluid and salt management; review emergency protocol."
_A_BONE = "Resistive + impact exercise, vitamin D and calcium management, periodic bone assessment."
_A_BEHAV = "Protect schedule and sleep, crew support, structured check-ins, Earth communication, early counselling."
ACTIONS = {
    "rad_immune": _A_IMMUNE, "env_immune": _A_IMMUNE, "env_infection": _A_IMMUNE,
    "rad_cardio": _A_CV, "grav_cv": _A_CV, "grav_fluid": _A_CV,
    "grav_bone": _A_BONE, "grav_muscle": _A_BONE, "grav_loading": _A_BONE, "grav_nutrition": _A_BONE,
    "iso_sleep": _A_BEHAV, "iso_mood": _A_BEHAV, "iso_cognition": _A_BEHAV,
    "iso_workload": _A_BEHAV, "iso_confinement": _A_BEHAV,
    "iso_reporting": "Routine self-monitoring, simple thresholds, peer checks, no-penalty reporting culture.",
    "rad_cns": "Check dose-rate; shelter or limit exposure per the radiation operations plan.",
    "rad_cancer": "Review cumulative dose against the career limit with the flight surgeon.",
    "env_resp": "Check cabin CO2 / O2 scrubbing, filtration and ventilation.",
}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def grade(bad: float, warn: float, crit: float) -> str:
    return CRITICAL if bad >= crit else WARNING if bad >= warn else NOMINAL


def risk_of(bad: float, warn: float, crit: float) -> float:
    """Map a badness value onto 0-100: <30 nominal, 30-65 warning, 65-100 critical."""
    if bad <= 0:
        return 0.0
    if bad < warn:
        return 30.0 * bad / warn
    if bad < crit:
        return 30.0 + 35.0 * (bad - warn) / (crit - warn)
    return 65.0 + 35.0 * min(1.0, (bad - crit) / max(crit - warn, 1e-9))


def evaluate(items, held: int = 0, held_code=None):
    """items: iterable of (bad, warn, crit, code, text), listed in priority order.

    Returns (level, risk, code, text). Among the items at the highest level the one
    whose code is already raised (`held_code`) wins, else the first listed - so the
    alert code does not flip between equal-level measures.
    `held` is the rank of an alert already raised for this feature: it only clears
    once a measure falls 10 % below its limit (hysteresis against threshold noise).
    """
    risk = 0.0
    cands = []
    for bad, warn, crit, c, t in items:
        lv = grade(bad, warn, crit)
        if held >= RANK[CRITICAL] and lv != CRITICAL and bad >= 0.9 * crit:
            lv = CRITICAL
        elif held >= RANK[WARNING] and lv == NOMINAL and bad >= 0.9 * warn:
            lv = WARNING
        cands.append((RANK[lv], lv, c, t))
        risk = max(risk, risk_of(bad, warn, crit))
    top = max(r for r, _, _, _ in cands)
    pool = [c for c in cands if c[0] == top]
    pick = next((c for c in pool if c[2] == held_code), pool[0])
    return pick[1], risk, pick[2], pick[3]


class Baseline:
    """Mean of the first n samples, then frozen."""

    def __init__(self, n: int = 30):
        self.n, self.vals, self.frozen = n, [], None

    def value(self) -> float:
        """Current baseline without adding a sample."""
        if self.frozen is not None:
            return self.frozen
        return sum(self.vals) / len(self.vals) if self.vals else 0.0

    def update(self, v: float) -> float:
        if self.frozen is not None:
            return self.frozen
        self.vals.append(v)
        m = sum(self.vals) / len(self.vals)
        if len(self.vals) >= self.n:
            self.frozen = m
        return m


def mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs) if xs else 0.0


def median(xs):
    xs = sorted(xs)
    n = len(xs)
    if n == 0:
        return 0.0
    return xs[n // 2] if n % 2 else 0.5 * (xs[n // 2 - 1] + xs[n // 2])


def slope(xs, ys):
    n = len(xs)
    if n < 3:
        return 0.0
    mx, my = mean(xs), mean(ys)
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx < 1e-12:
        return 0.0
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx


def day_bins(points):
    """points: iterable of (day, value) -> {int_day: mean value}"""
    acc = {}
    for d, v in points:
        acc.setdefault(int(math.floor(d)), []).append(v)
    return {d: mean(v) for d, v in acc.items()}


# ---------------------------------------------------------------------------
class ExtendedAnalyzer:
    def __init__(self, persistence: int = 2, career_limit_msv: float = 600.0):
        self.persistence = max(1, persistence)
        self.career_limit_msv = career_limit_msv
        self.reset()

    def reset(self) -> None:
        self.base = {k: Baseline(30) for k in ("lym", "hrv", "pwv", "rt", "err")}
        self.hrv_win = deque(maxlen=120)
        self.pwv_win = deque(maxlen=60)
        self.rt_win = deque(maxlen=10)
        self.dose_lym = deque(maxlen=400)
        self.rt_days = deque(maxlen=6000)     # (day, rt)
        self.err_days = deque(maxlen=6000)
        self.sleep_nights = {}                # int day -> (hours, eff)
        self.mood_days = {}                   # int day -> mood
        self.lean_days = {}                   # int day -> lean kg
        self.lean_base = None
        self.streak = {f: 0 for f in FEATURE_IDS}
        self.daily = {}                       # name -> {int day: latest value} for noisy daily measures
        self.held = {}                        # fid -> (level, code, text, risk) while an alert is raised
        self.clear_ct = {f: 0 for f in FEATURE_IDS}
        self.anchor = None                    # (mission_day, ts_ms) of last received clock value
        self.t0 = None
        self.prev_day = None
        self.cum_bmd_pct = 0.0
        self.first_day = None

    # ---- mission clock -----------------------------------------------------
    def _clock(self, ext, ts, mask, scale):
        if mask & G_DAILY2 and float(ext.get("mission_day", 0) or 0) > 0:
            d = float(ext["mission_day"])
            if self.anchor is None or d != self.anchor[0]:
                self.anchor = (d, ts)
            day = self.anchor[0] + (ts - self.anchor[1]) / 1000.0 * scale / 86400.0
        else:
            if self.t0 is None:
                self.t0 = ts
            day = 1.0 + (ts - self.t0) / 1000.0 * scale / 86400.0
        if self.prev_day is not None:
            if day < self.prev_day - 1.0:      # simulator restarted -> start over
                self.reset()
                return self._clock(ext, ts, mask, scale)
            day = max(day, self.prev_day)
        if self.first_day is None:
            self.first_day = day
        return day

    # ---- feature result plumbing ----------------------------------------
    def _done(self, fid, group, name, level, risk, value, detail, code, text, alerts):
        if level == NOMINAL:
            self.streak[fid] = 0
            conf = NOMINAL
        else:
            self.streak[fid] += 1
            conf = level if (level == CRITICAL or self.streak[fid] >= self.persistence) else NOMINAL
        # Hysteresis: do not drop (or flicker) an alert the moment noise crosses the limit.
        prev = self.held.get(fid)
        if prev is not None and RANK[conf] < RANK[prev[0]]:
            self.clear_ct[fid] += 1
            if self.clear_ct[fid] < HOLD_SAMPLES:
                conf, code, text, risk = prev
        else:
            self.clear_ct[fid] = 0
        if conf != NOMINAL:
            self.held[fid] = (conf, code, text, risk)
            alerts.append({"vital": fid, "level": conf, "code": code,
                           "message": f"{name}: {text}"})
        else:
            self.held.pop(fid, None)
            risk = min(risk, 29.9)
        return {"id": fid, "group": group, "name": name, "level": conf,
                "risk": round(risk, 1), "value": value, "detail": detail, "has_data": True,
                "action": ACTIONS.get(fid, "") if conf != NOMINAL else ""}

    def _med(self, key, value, n: int = 3) -> float:
        """Median of the last `n` days' values: a single noisy day must not raise an alarm."""
        d = self.daily.setdefault(key, {})
        d[self._di] = float(value)
        days = sorted(d)[-n:]
        return median([d[k] for k in days])

    def _eval(self, fid, items):
        prev = self.held.get(fid)
        return evaluate(items, RANK[prev[0]] if prev else 0, prev[1] if prev else None)

    def _nodata(self, fid, group, name, why="waiting for data"):
        self.streak[fid] = 0
        return {"id": fid, "group": group, "name": name, "level": NOMINAL, "risk": 0.0,
                "value": "--", "detail": why, "has_data": False, "action": ""}

    # ---- main entry -------------------------------------------------------
    def process(self, ext: dict, ts: int, core: dict) -> dict:
        """ext: extended values + groups_mask; core: hr, sys, temp, rad, spo2, dose_msv."""
        mask = int(ext.get("groups_mask", 0) or 0)
        scale = max(float(ext.get("time_scale", 0) or 0), 0.0) if mask & G_FAST else 1.0
        if scale == 0.0:
            scale = 1.0
        day = self._clock(ext, ts, mask, scale)
        self._di = int(math.floor(day))
        dday = 0.0 if self.prev_day is None else min(max(day - self.prev_day, 0.0), 5.0)
        self.prev_day = day
        dose = core["dose_msv"]
        rate = core["rad"]

        alerts, feats, metrics = [], {}, {"mission_day": round(day, 2),
                                          "cumulative_dose_msv": round(dose, 4)}
        g = ext.get

        # ===================== RADIATION =====================
        # --- immune ---
        if mask & G_IMMUNE:
            lym = float(g("lymphocytes_per_ul"))
            base = self.base["lym"].update(lym)
            decline = max(0.0, (base - lym) / base * 100.0) if base > 0 else 0.0
            self.dose_lym.append((dose, lym))
            sl = ""
            if len(self.dose_lym) >= 20:
                d0 = [p[0] for p in self.dose_lym]
                if max(d0) - min(d0) >= 0.5:
                    s = slope(d0, [p[1] for p in self.dose_lym]) * 100.0
                    sl = f"; dose-response {s:+.0f} cells/uL per 100 mSv"
            lv, rk, code, text = self._eval("rad_immune", [
                (decline, 15, 30, "IMMUNE_SUPPRESSION",
                 f"lymphocytes {lym:.0f}/uL, {decline:.0f}% below personal baseline {base:.0f}"),
                (max(0.0, 2000 - lym), 500, 1000, "LYMPHOPENIA",
                 f"lymphocyte count {lym:.0f}/uL (< {'1000' if lym < 1000 else '1500'})"),
            ])
            feats["rad_immune"] = self._done(
                "rad_immune", "radiation", "Radiation - immune", lv, rk,
                f"{lym:.0f} /uL", f"baseline {base:.0f}, decline {decline:.0f}%{sl}", code, text, alerts)
            metrics["lymphocyte_decline_pct"] = round(decline, 2)
        else:
            feats["rad_immune"] = self._nodata("rad_immune", "radiation", "Radiation - immune")

        # --- cardiovascular ---
        if mask & (G_FAST | G_IMMUNE) == (G_FAST | G_IMMUNE):
            hrv = float(g("hrv_rmssd_ms"))
            pwv = float(g("arterial_pwv_ms"))
            hb = self.base["hrv"].update(hrv)
            pb = self.base["pwv"].update(pwv)
            self.hrv_win.append(hrv)
            self.pwv_win.append(pwv)
            hrv_m, pwv_m = mean(self.hrv_win), mean(self.pwv_win)
            hrv_drop = max(0.0, (hb - hrv_m) / hb * 100.0)
            pwv_rise = max(0.0, (pwv_m - pb) / pb * 100.0)
            lv, rk, code, text = self._eval("rad_cardio", [
                (hrv_drop, 20, 40, "HRV_SUPPRESSION",
                 f"HRV (2-min mean) {hrv_m:.1f} ms is {hrv_drop:.0f}% below baseline {hb:.1f} ms"),
                (pwv_rise, 12, 25, "ARTERIAL_STIFFENING",
                 f"pulse-wave velocity {pwv_m:.2f} m/s is {pwv_rise:.0f}% above baseline {pb:.2f}"),
            ])
            feats["rad_cardio"] = self._done(
                "rad_cardio", "radiation", "Radiation - cardiovascular", lv, rk,
                f"HRV {hrv:.0f} ms", f"HRV {hrv_m:.1f} (base {hb:.1f}), PWV {pwv_m:.2f} m/s (base {pb:.2f}), dose {dose:.2f} mSv",
                code, text, alerts)
        else:
            feats["rad_cardio"] = self._nodata("rad_cardio", "radiation", "Radiation - cardiovascular")

        # --- central nervous system ---
        if mask & G_IMMUNE:
            rt = float(g("reaction_time_ms"))
            err = float(g("reaction_error_pct"))
            rb = self.base["rt"].update(rt)
            self.base["err"].update(err)
            self.rt_win.append(rt)
            self.rt_days.append((day, rt))
            self.err_days.append((day, err))
            rt_m = median(self.rt_win)
            inc = max(0.0, (rt_m - rb) / rb * 100.0)
            cause = " during elevated dose-rate" if rate > 50 else ""
            lv, rk, code, text = self._eval("rad_cns", [
                (inc, 15, 30, "CNS_SLOWING",
                 f"reaction time {rt_m:.0f} ms is {inc:.0f}% above baseline {rb:.0f} ms{cause}"),
                (err, 6, 12, "ERROR_RATE",
                 f"task error rate {err:.1f}%{cause}"),
            ])
            feats["rad_cns"] = self._done(
                "rad_cns", "radiation", "Radiation - CNS", lv, rk,
                f"{rt:.0f} ms", f"median {rt_m:.0f} ms (base {rb:.0f}), errors {err:.1f}%, dose-rate {rate:.0f} uSv/h",
                code, text, alerts)
        else:
            feats["rad_cns"] = self._nodata("rad_cns", "radiation", "Radiation - CNS")

        # --- cancer risk / dosimetry ---
        risk_pct = dose / 1000.0 * ICRP_CANCER_RISK_PER_SV * 100.0
        pct_limit = dose / self.career_limit_msv * 100.0
        elapsed = max(day - self.first_day, 1e-6)
        avg_rate = dose / elapsed if elapsed > 0.5 else rate * 24.0 / 1000.0
        days_left = (self.career_limit_msv - dose) / avg_rate if avg_rate > 1e-6 else float("inf")
        lv, rk, code, text = self._eval("rad_cancer", [
            (pct_limit, 40, 80, "DOSE_LIMIT",
             f"{dose:.1f} mSv = {pct_limit:.0f}% of the {self.career_limit_msv:.0f} mSv career limit"),
        ])
        feats["rad_cancer"] = self._done(
            "rad_cancer", "radiation", "Radiation - cancer risk", lv, rk,
            f"{dose:.2f} mSv",
            f"~{risk_pct:.3f}% added lifetime cancer risk (LNT {ICRP_CANCER_RISK_PER_SV*100:.1f}%/Sv, illustrative); "
            f"avg {avg_rate:.2f} mSv/day; "
            + ("limit not reachable at this rate" if days_left > 36500 else f"~{days_left:.0f} days to limit"),
            code, text, alerts)
        metrics.update(cancer_risk_pct=round(risk_pct, 4), career_limit_pct=round(pct_limit, 2),
                       avg_dose_msv_per_day=round(avg_rate, 4))

        # ===================== ISOLATION =====================
        if mask & G_DAILY:
            di = int(math.floor(day))
            self.sleep_nights[di] = (float(g("sleep_hours")), float(g("sleep_efficiency_pct")))
            self.mood_days[di] = float(g("mood_score"))
            recent = [self.sleep_nights[d] for d in sorted(self.sleep_nights)[-7:]]
            last_h, last_eff = recent[-1]
            debt = sum(max(0.0, SLEEP_NEED_H - h) for h, _ in recent)
            lv, rk, code, text = self._eval("iso_sleep", [
                (debt, 6, 14, "SLEEP_DEBT", f"{debt:.1f} h sleep debt over last {len(recent)} night(s)"),
                (max(0.0, 7.0 - last_h), 1.0, 2.5, "SHORT_SLEEP", f"last night only {last_h:.1f} h"),
                (max(0.0, 88.0 - last_eff), 8, 18, "POOR_SLEEP_QUALITY", f"sleep efficiency {last_eff:.0f}%"),
            ])
            feats["iso_sleep"] = self._done(
                "iso_sleep", "isolation", "Isolation - sleep", lv, rk,
                f"{last_h:.1f} h", f"efficiency {last_eff:.0f}%, 7-night mean {mean(h for h, _ in recent):.1f} h, debt {debt:.1f} h "
                f"(circadian-phase drift not modelled)", code, text, alerts)
            metrics["sleep_debt_h"] = round(debt, 2)

            vals = [self.mood_days[d] for d in sorted(self.mood_days)]
            mood = vals[-1]
            mb = mean(vals[:3])          # personal baseline = first three days
            lv, rk, code, text = self._eval("iso_mood", [
                (max(0.0, mb - mood), 12, 25, "MOOD_DECLINE", f"mood {mood:.0f}, {mb - mood:.0f} points below baseline {mb:.0f}"),
                (max(0.0, 70.0 - mood), 10, 25, "LOW_MOOD", f"mood score {mood:.0f} (< 70 low)"),
            ])
            feats["iso_mood"] = self._done(
                "iso_mood", "isolation", "Isolation - mood", lv, rk,
                f"{mood:.0f}/100", f"baseline {mb:.0f}, {len(vals)} day(s) of data", code, text, alerts)
        else:
            feats["iso_sleep"] = self._nodata("iso_sleep", "isolation", "Isolation - sleep")
            feats["iso_mood"] = self._nodata("iso_mood", "isolation", "Isolation - mood")

        # --- cognition (long horizon) ---
        if mask & G_IMMUNE and self.rt_days:
            rb = self.base["rt"].value()
            recent3 = [v for d, v in self.rt_days if d >= day - 3.0]
            rt3 = mean(recent3)
            inc = max(0.0, (rt3 - rb) / rb * 100.0)
            bins = day_bins(list(self.rt_days)[-3000:])
            ds = sorted(bins)[-7:]
            trend = slope(ds, [bins[d] for d in ds]) if len(ds) >= 3 else 0.0
            err3 = mean(v for d, v in self.err_days if d >= day - 3.0)
            lv, rk, code, text = self._eval("iso_cognition", [
                (inc, 10, 20, "COGNITIVE_DECLINE", f"3-day mean reaction time {rt3:.0f} ms is {inc:.0f}% above baseline {rb:.0f} ms"),
                (max(0.0, trend), 4.0, 8.0, "COGNITIVE_DRIFT", f"reaction time drifting +{trend:.1f} ms/day"),
                (err3, 5, 10, "COGNITIVE_ERRORS", f"3-day mean error rate {err3:.1f}%"),
            ])
            feats["iso_cognition"] = self._done(
                "iso_cognition", "isolation", "Isolation - cognition", lv, rk,
                f"{rt3:.0f} ms (3d)", f"trend {trend:+.2f} ms/day over {len(ds)} day(s), errors {err3:.1f}%",
                code, text, alerts)
        else:
            feats["iso_cognition"] = self._nodata("iso_cognition", "isolation", "Isolation - cognition")

        # --- workload ---
        if mask & G_NUTR:
            wl, wh = self._med("wl", g("workload_index")), self._med("wh", g("work_hours"))
            lv, rk, code, text = self._eval("iso_workload", [
                (wl, 75, 90, "WORKLOAD_HIGH", f"workload index {wl:.0f}/100"),
                (max(0.0, wh - 10.0), 2.0, 4.0, "LONG_WORK_DAY", f"{wh:.1f} h work day"),
            ])
            feats["iso_workload"] = self._done(
                "iso_workload", "isolation", "Behavioral - workload", lv, rk,
                f"{wl:.0f}/100", f"{wh:.1f} h work day; sustained overload erodes sleep, mood and self-monitoring",
                code, text, alerts)
            metrics["workload_index"] = round(wl, 1)
        else:
            feats["iso_workload"] = self._nodata("iso_workload", "isolation", "Behavioral - workload")

        # --- confinement: social contact + communication with Earth, and self-reporting ---
        if mask & G_BEHAV:
            soc, comm = self._med("soc", g("social_contact_min")), self._med("comm", g("earth_comm_min"))
            lv, rk, code, text = self._eval("iso_confinement", [
                (max(0.0, 120.0 - soc), 40, 80, "SOCIAL_ISOLATION", f"only {soc:.0f} min social contact today"),
                (max(0.0, 30.0 - comm), 15, 25, "EARTH_COMMS_LOW", f"only {comm:.0f} min communication with Earth"),
            ])
            feats["iso_confinement"] = self._done(
                "iso_confinement", "isolation", "Behavioral - confinement", lv, rk,
                f"{soc:.0f} min", f"social contact {soc:.0f} min/day (target >= 120), Earth communication {comm:.0f} min/day (target >= 30)",
                code, text, alerts)

            sc, delay, peer = (self._med("sc", g("selfcheck_pct")), self._med("delay", g("report_delay_h")),
                               self._med("peer", g("peer_check_pct")))
            lv, rk, code, text = self._eval("iso_reporting", [
                (max(0.0, 95.0 - sc), 20, 40, "SELF_MONITORING_LAPSE", f"self-monitoring only {sc:.0f}% complete"),
                (delay, 6.0, 12.0, "REPORT_DELAY", f"symptoms reported {delay:.1f} h after onset"),
                (max(0.0, 90.0 - peer), 15, 35, "PEER_CHECK_LAPSE", f"peer checks only {peer:.0f}% complete"),
            ])
            feats["iso_reporting"] = self._done(
                "iso_reporting", "isolation", "Behavioral - self-reporting", lv, rk,
                f"{sc:.0f}% checks", f"report delay {delay:.1f} h, peer checks {peer:.0f}%; late self-detection risk",
                code, text, alerts)
            metrics["report_delay_h"] = round(delay, 1)
        else:
            feats["iso_confinement"] = self._nodata("iso_confinement", "isolation", "Behavioral - confinement")
            feats["iso_reporting"] = self._nodata("iso_reporting", "isolation", "Behavioral - self-reporting")

        # ===================== GRAVITY =====================
        if mask & G_DAILY:
            ntx = float(g("bone_ntx"))
            excess = max(0.0, ntx - 30.0)
            monthly = 0.10 * excess                      # %/month projected BMD loss
            self.cum_bmd_pct -= monthly / 30.0 * dday
            lv, rk, code, text = self._eval("grav_bone", [
                (monthly, 1.0, 1.5, "BONE_LOSS_RATE", f"projected bone-density loss {monthly:.2f} %/month (NTx {ntx:.1f})"),
                (-self.cum_bmd_pct, 2.0, 5.0, "BONE_LOSS_CUM", f"estimated cumulative bone loss {-self.cum_bmd_pct:.2f}%"),
            ])
            feats["grav_bone"] = self._done(
                "grav_bone", "gravity", "Gravity - bone density", lv, rk,
                f"{monthly:.2f} %/mo", f"NTx {ntx:.1f} (norm 30), est. cumulative change {self.cum_bmd_pct:+.2f}%",
                code, text, alerts)
            metrics.update(bmd_loss_pct_month=round(monthly, 3), bmd_change_pct=round(self.cum_bmd_pct, 3))

            lean = float(g("lean_mass_kg"))
            di = int(math.floor(day))
            self.lean_days[di] = lean
            if self.lean_base is None:
                self.lean_base = lean
            ds = sorted(self.lean_days)
            week_rate = 0.0
            if len(ds) >= 2:
                then_d = next((d for d in ds if d >= di - 7), ds[0])
                span = di - then_d
                if span >= 2:
                    then_v = self.lean_days[then_d]
                    week_rate = max(0.0, (then_v - lean) / then_v * 100.0 * 7.0 / span)
            cum = max(0.0, (self.lean_base - lean) / self.lean_base * 100.0)
            leg = float(g("leg_strength_pct")) if mask & G_DAILY2 else 100.0
            ex = float(g("exercise_min")) if mask & G_DAILY2 else 120.0
            lv, rk, code, text = self._eval("grav_muscle", [
                (week_rate, 1.0, 2.0, "MUSCLE_LOSS_RATE", f"lean mass falling {week_rate:.2f} %/week"),
                (cum, 5, 10, "MUSCLE_LOSS_CUM", f"lean mass {cum:.1f}% below start"),
                (max(0.0, 100.0 - leg), 10, 20, "STRENGTH_LOSS", f"leg strength {leg:.0f}% of baseline"),
            ])
            feats["grav_muscle"] = self._done(
                "grav_muscle", "gravity", "Gravity - muscle mass", lv, rk,
                f"{lean:.1f} kg", f"{cum:.1f}% below start, {week_rate:.2f} %/wk, strength {leg:.0f}%, exercise {ex:.0f} min",
                code, text, alerts)
            metrics.update(lean_change_pct=round(-cum, 3), lean_loss_pct_week=round(week_rate, 3))

            fluid = float(g("fluid_index"))
            expected = 1.04 + 0.10 * math.exp(-max(day - 1.0, 0.0) / 4.0)
            exc = (fluid - expected) * 100.0
            lv, rk, code, text = self._eval("grav_fluid", [
                (max(0.0, exc), 5, 10, "FLUID_SHIFT",
                 f"fluid index {fluid:.3f} is {exc:.1f} points above the expected adaptation curve ({expected:.3f})"),
            ])
            feats["grav_fluid"] = self._done(
                "grav_fluid", "gravity", "Gravity - fluid shift", lv, rk,
                f"{fluid:.3f}", f"expected {expected:.3f} on day {day:.1f}; early-mission headward shift is normal",
                code, text, alerts)
        else:
            for fid, n in (("grav_bone", "Gravity - bone density"), ("grav_muscle", "Gravity - muscle mass"),
                           ("grav_fluid", "Gravity - fluid shift")):
                feats[fid] = self._nodata(fid, "gravity", n)

        if mask & G_DAILY2:
            ortho = float(g("orthostatic_hr_rise"))
            lv, rk, code, text = self._eval("grav_cv", [
                (ortho, 22, 30, "ORTHOSTATIC_INTOLERANCE", f"standing HR rise {ortho:.0f} bpm (>= 30 = intolerance)"),
            ])
            ready = "NOT READY" if lv == CRITICAL else "CAUTION" if lv == WARNING else "READY"
            feats["grav_cv"] = self._done(
                "grav_cv", "gravity", "Gravity - CV deconditioning", lv, rk,
                f"+{ortho:.0f} bpm", f"stand-test HR rise (normal 10-15); EVA/landing readiness: {ready}",
                code, text, alerts)
            metrics["orthostatic_rise_bpm"] = round(ortho, 1)
        else:
            feats["grav_cv"] = self._nodata("grav_cv", "gravity", "Gravity - CV deconditioning")

        # --- mechanical loading (countermeasure delivered) ---
        if mask & G_NUTR:
            ml = self._med("ml", g("mech_load_pct"))
            ex = self._med("ex", g("exercise_min")) if mask & G_DAILY2 else 120.0
            lv, rk, code, text = self._eval("grav_loading", [
                (max(0.0, 90.0 - ex), 30, 70, "COUNTERMEASURE_SKIPPED", f"only {ex:.0f} min exercise today (target 120)"),
                (max(0.0, 100.0 - ml), 30, 60, "LOADING_DEFICIT", f"mechanical loading {ml:.0f}% of prescription"),
            ])
            feats["grav_loading"] = self._done(
                "grav_loading", "gravity", "Gravity - mechanical loading", lv, rk,
                f"{ml:.0f}% of Rx", f"exercise {ex:.0f} min/day; resistive + impact loading drives bone and muscle retention",
                code, text, alerts)
            metrics["mech_load_pct"] = round(ml, 1)
        else:
            feats["grav_loading"] = self._nodata("grav_loading", "gravity", "Gravity - mechanical loading")

        # --- nutrition ---
        if mask & G_NUTR:
            vd, ca, en = float(g("vitamin_d_ngml")), self._med("ca", g("calcium_intake_mg")), self._med("en", g("energy_intake_kcal"))
            na = self._med("na", g("sodium_intake_mg")) if mask & G_BEHAV else 3200.0
            lv, rk, code, text = self._eval("grav_nutrition", [
                (max(0.0, 900.0 - ca), 200, 400, "CALCIUM_LOW", f"calcium intake {ca:.0f} mg/day (target >= 1000)"),
                (max(0.0, 2500.0 - en), 500, 900, "ENERGY_DEFICIT", f"energy intake {en:.0f} kcal/day"),
                (max(0.0, 30.0 - vd), 6, 10, "VITAMIN_D_LOW", f"vitamin D {vd:.1f} ng/mL (< 20 deficient)"),
                (max(0.0, na - 3500.0), 500, 1500, "SODIUM_HIGH", f"sodium intake {na:.0f} mg/day (fluid retention / BP)"),
            ])
            feats["grav_nutrition"] = self._done(
                "grav_nutrition", "gravity", "Gravity - nutrition", lv, rk,
                f"vit D {vd:.0f} ng/mL", f"calcium {ca:.0f} mg, energy {en:.0f} kcal, sodium {na:.0f} mg; supports bone health",
                code, text, alerts)
            metrics["vitamin_d_ngml"] = round(vd, 1)
        else:
            feats["grav_nutrition"] = self._nodata("grav_nutrition", "gravity", "Gravity - nutrition")

        # ===================== ENVIRONMENT =====================
        immune_idx = None
        if mask & G_IMMUNE and mask & G_DAILY2:
            lym = float(g("lymphocytes_per_ul"))
            lb = self.base["lym"].value()
            decline = max(0.0, (lb - lym) / lb * 100.0) if lb else 0.0
            cort = float(g("cortisol_ugdl"))
            crp = float(g("crp_mgl"))
            p_l = min(40.0, 1.5 * decline)
            p_c = min(25.0, 20.0 * max(0.0, (cort - 12.0) / 12.0))
            p_r = min(35.0, 3.5 * max(0.0, crp - 2.0))
            immune_idx = max(0.0, 100.0 - p_l - p_c - p_r)
            lv, rk, code, text = self._eval("env_immune", [
                (100.0 - immune_idx, 25, 50, "IMMUNE_DEPRESSION",
                 f"immune index {immune_idx:.0f}/100 (lymphocytes -{p_l:.0f}, cortisol -{p_c:.0f}, CRP -{p_r:.0f})"),
            ])
            feats["env_immune"] = self._done(
                "env_immune", "environment", "Environment - immune function", lv, rk,
                f"{immune_idx:.0f}/100", f"cortisol {cort:.1f} ug/dL, CRP {crp:.1f} mg/L, lymphocyte decline {decline:.0f}%",
                code, text, alerts)
            metrics["immune_index"] = round(immune_idx, 1)
        else:
            feats["env_immune"] = self._nodata("env_immune", "environment", "Environment - immune function")

        if mask & G_FAST:
            co2, o2, pm, rr = (float(g(k)) for k in ("cabin_co2_mmhg", "cabin_o2_pct", "pm25_ugm3", "resp_rate_bpm"))
            hum = float(g("humidity_pct")) if mask & G_DAILY2 else 45.0
            lv, rk, code, text = self._eval("env_resp", [
                (co2, 4.0, 6.0, "HIGH_CO2", f"cabin ppCO2 {co2:.2f} mmHg"),
                (max(0.0, 20.9 - o2), 1.4, 2.9, "LOW_O2", f"cabin O2 {o2:.1f}%"),
                (pm, 35, 100, "PARTICULATES", f"PM2.5 {pm:.0f} ug/m3"),
                (max(0.0, rr - 16.0, 12.0 - rr), 4, 8, "ABNORMAL_RESP_RATE", f"respiratory rate {rr:.0f}/min"),
                (max(0.0, 30.0 - hum, hum - 65.0), 5, 15, "HUMIDITY", f"relative humidity {hum:.0f}%"),
            ])
            feats["env_resp"] = self._done(
                "env_resp", "environment", "Environment - respiratory", lv, rk,
                f"CO2 {co2:.1f} mmHg",
                f"O2 {o2:.1f}%, PM2.5 {pm:.0f}, RH {hum:.0f}%, resp {rr:.0f}/min (limits are illustrative)",
                code, text, alerts)
        else:
            feats["env_resp"] = self._nodata("env_resp", "environment", "Environment - respiratory")

        if mask & G_IMMUNE and immune_idx is not None:
            micro = float(g("microbial_cfu_m3"))
            crp = float(g("crp_mgl"))
            t_micro = min(1.0, micro / 1500.0)
            t_fever = min(1.0, max(0.0, (core["temp"] - 37.2) / 1.8))
            t_imm = min(1.0, max(0.0, (100.0 - immune_idx) / 60.0))
            t_crp = min(1.0, max(0.0, (crp - 3.0) / 20.0))
            score = 100.0 * (0.35 * t_micro + 0.25 * t_fever + 0.20 * t_imm + 0.20 * t_crp)
            lv, rk, code, text = self._eval("env_infection", [
                (score, 35, 60, "INFECTION_RISK",
                 f"infection risk score {score:.0f}/100 (microbes {micro:.0f} CFU/m3, temp {core['temp']:.1f} C, CRP {crp:.1f})"),
                (micro, 500, 1000, "MICROBIAL_LOAD", f"cabin microbial load {micro:.0f} CFU/m3"),
            ])
            feats["env_infection"] = self._done(
                "env_infection", "environment", "Environment - infection risk", lv, rk,
                f"{score:.0f}/100", f"microbes {micro:.0f} CFU/m3, temp {core['temp']:.2f} C, immune {immune_idx:.0f}, CRP {crp:.1f}",
                code, text, alerts)
            metrics["infection_score"] = round(score, 1)
        else:
            feats["env_infection"] = self._nodata("env_infection", "environment", "Environment - infection risk")

        # ===================== roll-up =====================
        ordered = [feats[f] for f in FEATURE_IDS]
        hazards, scores = [], []
        for hid, hname, fids in HAZARDS:
            fs = [feats[f] for f in fids]
            lvl = max((f["level"] for f in fs), key=lambda l: RANK[l])
            score = max(f["risk"] for f in fs)
            scores.append(score)
            hazards.append({"id": hid, "name": hname, "level": lvl, "score": round(score, 1)})
        metrics["composite_risk"] = round(0.5 * max(scores) + 0.5 * mean(scores), 1)
        overall = max((a["level"] for a in alerts), key=lambda l: RANK[l], default=NOMINAL)
        return {"features": ordered, "hazards": hazards, "metrics": metrics,
                "alerts": alerts, "overall": overall}
